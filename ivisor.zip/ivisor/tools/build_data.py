import json, re
import sys
D=sys.argv[1] if len(sys.argv)>1 else 'data/'
pv=json.load(open(D+'pvpoke.json'))
gm=json.load(open(D+'latest.json'))
def i18n(l):
    a=json.load(open(D+f'i18n_{l}.json'))['data']; return dict(zip(a[0::2],a[1::2]))
de=i18n('german'); en=i18n('english')
TYPES=['normal','fighting','flying','poison','ground','rock','bug','ghost','steel','fire','water','grass','electric','psychic','ice','dragon','dark','fairy']
tmpl={e['templateId']:e['data'] for e in gm}
# type chart
chart=[]
for t in TYPES:
    chart.append(tmpl['POKEMON_TYPE_'+t.upper()]['typeEffective']['attackScalar'])
pl=tmpl['PLAYER_LEVEL_SETTINGS']['playerLevel']
up=tmpl['POKEMON_UPGRADE_SETTINGS']['pokemonUpgrades']
# PvE moves
pve={}; moveNum={}
for tid,d in tmpl.items():
    if 'moveSettings' in d:
        m=d['moveSettings']; mid=str(m['movementId'])
        num=int(re.match(r'V(\d+)_MOVE',tid).group(1)) if re.match(r'V(\d+)_MOVE',tid) else None
        pve[mid]={'p':m.get('power',0),'d':m.get('durationMs',1000),'e':m.get('energyDelta',0),'dw':m.get('damageWindowStartMs',0)}
        if num: moveNum[mid]=num
typeDe={t:de.get('pokemon_type_'+t,t.title()) for t in TYPES}
moves=[]
for m in pv['moves']:
    mid=m['moveId']; fast=m['energyGain']>0 or m['energy']==0
    key=None
    for k in ([mid+'_FAST',mid] if fast else [mid]):
        if k in pve: key=k;break
    if key is None and mid.startswith('HIDDEN_POWER'): key='HIDDEN_POWER_FAST'
    if key is None and mid.endswith('_BLASTOISE'): key=None
    num=moveNum.get(key) if key else None
    nde=de.get('move_name_%04d'%num) if num else None
    o={'id':mid,'n':m['name'],'nd':nde or m['name'],'t':m['type'],'f':1 if fast else 0,
       'pp':m['power'],'pe':(m['energyGain'] if fast else m['energy']),'tu':m.get('turns',1)}
    if 'buffs' in m:
        o['bf']=m['buffs']; o['bt']=m.get('buffTarget','self'); o['bc']=float(m.get('buffApplyChance',1))
    if key:
        x=pve[key]; o['ep']=x['p']; o['ed']=x['d']; o['ee']=abs(x['e']); o['ew']=x['dw']
    moves.append(o)
FORM_DE={'Alolan':'Alola','Galarian':'Galar','Hisuian':'Hisui','Paldean':'Paldea','Mega':'Mega','Shadow':'Crypto','Armored':'Rüstung'}
mons=[]
for p in pv['pokemon']:
    tags=p.get('tags',[])
    if 'shadow' in tags or 'duplicate' in tags or not p.get('released',True): continue
    if p['speciesId'].endswith('_shadow'): continue
    base=de.get('pokemon_name_%04d'%p['dex'])
    nm=p['speciesName']; ndisp=nm
    mm=re.match(r'^(.*?) \((.*)\)$',nm)
    if base:
        if mm:
            form=' '.join(FORM_DE.get(w,w) for w in mm.group(2).split())
            ndisp=f"{base} ({form})"
        elif nm.startswith('Mega '):
            ndisp='Mega-'+base+nm[len('Mega '+en.get('pokemon_name_%04d'%p['dex'],'')):] 
        else: ndisp=base
    b=p['baseStats']
    o={'id':p['speciesId'],'dx':p['dex'],'n':nm,'nd':ndisp,'a':b['atk'],'d':b['def'],'s':b['hp'],
       't':p['types'][:1]+[t for t in p['types'][1:] if t!='none'],'fm':p['fastMoves'],'cm':p['chargedMoves']}
    fl=0
    if 'legendary' in tags: fl|=1
    if 'mythical' in tags: fl|=2
    if 'shadoweligible' in tags: fl|=4
    if 'mega' in tags or 'supermega' in tags or '_mega' in p['speciesId'] or p['speciesId'].endswith('_primal'): fl|=8
    if 'ultrabeast' in tags: fl|=16
    if 'untradeable' in tags: fl|=32
    o['fl']=fl
    fam=p.get('family',{})
    if fam.get('evolutions'): o['ev']=fam['evolutions']
    if fam.get('parent'): o['pa']=fam['parent']
    if fam.get('id'): o['fa']=fam['id']
    if p.get('elite'): o['el']=p['elite']
    mons.append(o)
# candy names per family (de/en) for OCR
cand={}
for p in mons:
    cand.setdefault(p['fa'] if 'fa' in p else p['id'],p['dx'])
out={'version':pv.get('timestamp',''),'types':TYPES,'typesDe':[typeDe[t] for t in TYPES],'chart':chart,
     'cpm':pl['cpMultiplier'],'dust':up['stardustCost'],'candy':up['candyCost'],'xl':up['xlCandyCost'],
     'mult':{'shadowDust':up['shadowStardustMultiplier'],'shadowCandy':up['shadowCandyMultiplier'],'purDust':up['purifiedStardustMultiplier'],'purCandy':up['purifiedCandyMultiplier']},
     'maxLevel':up['maxNormalUpgradeLevel'],'pokemon':mons,'moves':moves}
meta={}
for c in (500,1500,2500,10000):
    r=json.load(open(D+f'r{c}.json'))
    meta[str(c)]=[[x['speciesId'],x['score']]+x.get('moveset',[]) for x in r]
out['meta']=meta
json.dump(out,open('app/src/main/assets/gamedata.json','w'),ensure_ascii=False,separators=(',',':'))
print(len(mons),len(moves),sum(1 for m in moves if 'ep' not in m))
print([m['id'] for m in moves if 'ep' not in m][:30])
print([ (p['id'],p['nd']) for p in mons][:5], [(p['id'],p['nd']) for p in mons if p['dx'] in (26,6,150,905)])
