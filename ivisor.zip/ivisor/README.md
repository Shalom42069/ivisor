# IVisor – freier IV-Scanner für Pokémon GO

Android-App (Kotlin + Jetpack Compose) für das OnePlus 15 (läuft ab Android 11).
Funktioniert wie Poke Genie, nur ohne Paywall: Bildschirm per Overlay scannen, IVs berechnen,
PvP-Ränge, Raid-Konter, Sammlung mit Sortierung und Entwicklungs-Empfehlung.

## Features
- **Overlay-Scanner**: schwebende Blase über Pokémon GO → Tippen = Scan (Bildschirmaufnahme + ML-Kit-Texterkennung, komplett offline)
  - liest WP/CP, KP/HP, Name, Bonbon-Familie, Sternenstaubkosten; deutsche & englische Spielsprache
  - erkennt Crypto/Erlöst/Glücks automatisch über die Staubkosten
  - **Bewertung**: Bewertungsbalken werden automatisch gelesen und mit dem vorherigen Scan kombiniert → exakte IVs
  - **Level-Bogen**: kalibriert sich automatisch, grenzt Level zusätzlich ein
  - **Auto-Scan / Stapel-Scan** (Blase lange drücken): einfach durch die Pokémon wischen, alles landet in der Sammlung
  - Namensvorschlag (Vorlage frei konfigurierbar, z. B. `96⑮⑭⑬`) → antippen = kopiert
- **Sammlung**: alle gescannten Pokémon mit IVs, sortierbar (IV %, WP, Level, SL-/HL-Rang, Datum, Name, Nr.), filterbar (Sterne, Favoriten, exakt), CSV-Export
- **„Lohnt sich zu entwickeln“**: alle Pokémon ab 3★ (oder nur 4★), sortiert nach Stärke der Weiterentwicklung (PvP-Rang gewichtet mit PvPoke-Meta, Raid-Stärke, Meisterliga) inkl. Begründung
- **PvP**: Rang von 4096 für Little/Super/Hyper/Meister (Level 40/50/51), für Art + alle Entwicklungen, Top-IVs, Meta-Moveset mit Attacken-Zählern
- **Raid-Konter**: DPS/TDO-Ranking gegen jeden Boss, Wetter, Crypto/Mega, „nur meine Pokémon“, Boss-WP, Fang-WP (100 %-Werte)
- **Rechner**: manueller IV-Rechner mit Bewertung, Power-Up-Kosten (Staub/Bonbons/XL, Crypto/Erlöst/Glücks), Typen-Tabelle
- **Daten-Update** direkt in der App (PvPoke-Gamemaster + Ranglisten)

## Bauen
- Android Studio öffnen → Projektordner wählen → *Run*; oder
- `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk` (mit Debug-Key signiert, direkt installierbar); oder
- Auf GitHub pushen → Action „APK bauen“ lädt die APK als Artefakt hoch.

## Erster Start
1. „Overlay starten“ → „Über anderen Apps einblenden“ erlauben → Benachrichtigungen erlauben → Bildschirmaufnahme erlauben (*Gesamter Bildschirm* oder nur Pokémon GO).
2. Trainerlevel einstellen.
3. In Pokémon GO ein Pokémon öffnen und die Blase antippen.

## Spieldaten neu erzeugen
`tools/build_data.py <ordner>` erwartet dort `pvpoke.json` (PvPoke gamemaster.min.json), `latest.json` (PokeMiners game_masters),
`i18n_german.json`/`i18n_english.json` (PokeMiners pogo_assets) und `r500/r1500/r2500/r10000.json` (PvPoke-Ranglisten).

Inoffizielle Fan-App. IVisor liest nur Bildschirminhalte, greift nicht ins Spiel ein und nutzt keine Spiel-APIs.
