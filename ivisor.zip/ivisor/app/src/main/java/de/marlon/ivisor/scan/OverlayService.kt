package de.marlon.ivisor.scan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import de.marlon.ivisor.R
import de.marlon.ivisor.core.*
import de.marlon.ivisor.data.Repo
import de.marlon.ivisor.ui.MainActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.PI

sealed interface OverlayUi {
    data object Hidden : OverlayUi
    data object Scanning : OverlayUi
    data class Result(
        val outcome: ScanOutcome,
        val record: ScanRecord?,
        val appraisal: Appraisal?,
        val levelHint: Double?,
    ) : OverlayUi
    data class Error(val message: String) : OverlayUi
}

class OverlayService : LifecycleService(), SavedStateRegistryOwner {
    companion object {
        const val ACTION_START = "de.marlon.ivisor.START"
        const val ACTION_STOP = "de.marlon.ivisor.STOP"
        const val ACTION_SCAN = "de.marlon.ivisor.SCAN"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 42

        fun start(ctx: Context, resultCode: Int, data: Intent) {
            val i = Intent(ctx, OverlayService::class.java).setAction(ACTION_START)
                .putExtra(EXTRA_CODE, resultCode).putExtra(EXTRA_DATA, data)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, OverlayService::class.java).setAction(ACTION_STOP))
        }
    }

    private val savedStateController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    private lateinit var wm: WindowManager
    private var grabber: ScreenGrabber? = null
    private var bubble: ComposeView? = null
    private var panel: ComposeView? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private val scanMutex = Mutex()
    private var autoJob: Job? = null
    private var stopping = false

    // --- State für die Compose-Oberflächen ---
    var ui by mutableStateOf<OverlayUi>(OverlayUi.Hidden)
    var bubbleBadge by mutableStateOf<String?>(null)
    var bubbleBusy by mutableStateOf(false)
    var panelFocusable by mutableStateOf(false)

    override fun onCreate() {
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        createChannel()
    }

    override fun onBind(intent: Intent): IBinder? { super.onBind(intent); return null }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START -> {
                startForeground(NOTIF_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                @Suppress("DEPRECATION")
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else intent.getParcelableExtra(EXTRA_DATA)
                if (data == null || grabber != null) return START_NOT_STICKY
                val mpm = getSystemService(MediaProjectionManager::class.java)
                val projection = mpm.getMediaProjection(code, data)
                if (projection == null) { stopSelf(); return START_NOT_STICKY }
                grabber = ScreenGrabber(this, projection) { lifecycleScope.launch(Dispatchers.Main) { shutdown() } }.also { it.start() }
                showBubble()
                Repo.overlayRunning = true
            }
            ACTION_SCAN -> scan()
            ACTION_STOP -> shutdown()
        }
        return START_NOT_STICKY
    }

    private fun shutdown() {
        if (stopping) return
        stopping = true
        autoJob?.cancel(); Repo.autoScanActive = false
        runCatching { bubble?.let { wm.removeView(it) } }; bubble = null
        runCatching { panel?.let { wm.removeView(it) } }; panel = null
        grabber?.release(); grabber = null
        Repo.overlayRunning = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (!stopping) shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ Fenster

    private fun overlayParams(w: Int, h: Int, focusable: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        (if (focusable) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT,
    )

    private fun composeView(content: @androidx.compose.runtime.Composable () -> Unit) = ComposeView(this).apply {
        setViewTreeLifecycleOwner(this@OverlayService)
        setViewTreeSavedStateRegistryOwner(this@OverlayService)
        setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
        setContent(content)
    }

    private fun showBubble() {
        val s = Repo.settings
        bubbleParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, false).apply {
            gravity = Gravity.TOP or Gravity.START; x = s.bubbleX; y = s.bubbleY
        }
        bubble = composeView {
            Bubble(
                service = this,
                onTap = { if (ui is OverlayUi.Hidden || ui is OverlayUi.Error) scan() else hidePanel() },
                onLongPress = { toggleAutoScan() },
                onDrag = { dx, dy -> moveBubble(dx, dy) },
                onDragEnd = { Repo.updateSettings { it.copy(bubbleX = bubbleParams.x, bubbleY = bubbleParams.y) } },
            )
        }
        wm.addView(bubble, bubbleParams)
    }

    private fun moveBubble(dx: Float, dy: Float) {
        val b = bubble ?: return
        bubbleParams.x += dx.toInt(); bubbleParams.y += dy.toInt()
        runCatching { wm.updateViewLayout(b, bubbleParams) }
    }

    private fun ensurePanel() {
        if (panel != null) return
        panelParams = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT, false).apply {
            gravity = Gravity.BOTTOM
            alpha = Repo.settings.panelAlpha
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        panel = composeView { ResultPanel(this) }
        wm.addView(panel, panelParams)
    }

    fun updatePanelFocus(f: Boolean) {
        val p = panel ?: return
        panelFocusable = f
        panelParams.flags = if (f) panelParams.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else panelParams.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        runCatching { wm.updateViewLayout(p, panelParams) }
    }

    fun hidePanel() {
        ui = OverlayUi.Hidden
        updatePanelFocus(false)
        runCatching { panel?.let { wm.removeView(it) } }; panel = null
    }

    private fun setOverlayVisible(v: Boolean) {
        val vis = if (v) View.VISIBLE else View.INVISIBLE
        bubble?.visibility = vis; panel?.visibility = vis
    }

    fun openApp() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        hidePanel()
    }

    fun copy(text: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Name", text))
        if (Build.VERSION.SDK_INT < 33) Toast.makeText(this, "Kopiert: $text", Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ Scannen

    fun scan() {
        val g = grabber ?: return
        val data = Repo.gameData ?: run { ui = OverlayUi.Error("Spieldaten werden noch geladen …"); ensurePanel(); return }
        if (scanMutex.isLocked) return
        lifecycleScope.launch {
            scanMutex.withLock {
                bubbleBusy = true
                val prev = ui as? OverlayUi.Result
                setOverlayVisible(false)
                val bmp = g.grab(freshAfterMs = 140)
                setOverlayVisible(true)
                if (bmp == null) { bubbleBusy = false; ui = OverlayUi.Error("Kein Bild erhalten. Bildschirmaufnahme aktiv?"); ensurePanel(); return@withLock }
                val result = withContext(Dispatchers.Default) { analyze(data, bmp, prev) }
                bmp.recycle()
                bubbleBusy = false
                ui = result
                ensurePanel()
                if (result is OverlayUi.Result && result.record == null && Repo.settings.autoSave && result.outcome.results.isNotEmpty()) {
                    val rec = Repo.saveScan(result.outcome)
                    ui = result.copy(record = rec)
                }
            }
        }
    }

    /** Neu berechnen, z. B. nach manueller Artwahl im Panel. */
    fun recompute(species: Pokemon) {
        val cur = ui as? OverlayUi.Result ?: return
        val data = Repo.gameData ?: return
        val s = Repo.settings
        val out = ScanEngine.resolve(data, cur.outcome.parsed, s.scanSettings(), species, cur.levelHint, s.origin.floor, cur.appraisal ?: Appraisal())
        val rec = if (s.autoSave && out.results.isNotEmpty()) Repo.saveScan(out) else null
        ui = cur.copy(outcome = out, record = rec)
    }

    fun saveCurrent() {
        val cur = ui as? OverlayUi.Result ?: return
        val rec = Repo.saveScan(cur.outcome) ?: return
        ui = cur.copy(record = rec)
    }

    private suspend fun analyze(g: GameData, bmp: Bitmap, prev: OverlayUi.Result?): OverlayUi {
        val lines = runCatching { Ocr.lines(bmp) }.getOrNull()
            ?: return OverlayUi.Error("Texterkennung fehlgeschlagen.")
        val s = Repo.settings
        var parsed = ScanParser.parse(lines, bmp.width, bmp.height, ScanParser.validDustValues(g))

        // Bewertungsbildschirm: Balken lesen und mit vorherigem Scan kombinieren
        var appraisal: Appraisal? = null
        if (s.autoAppraisal && parsed.appraisalVisible) appraisal = ImageAnalysis.readAppraisal(bmp, lines)
        if (appraisal != null && prev != null && (parsed.cp == null || parsed.cp == prev.outcome.parsed.cp)) {
            // Beim Bewerten sind KP/Staub oft verdeckt → Werte vom vorigen Scan übernehmen
            val pp = prev.outcome.parsed
            parsed = pp.copy(lucky = pp.lucky || parsed.lucky)
        }
        if (!parsed.isPokemonScreen && parsed.cp == null)
            return OverlayUi.Error("Kein Pokémon-Detailbildschirm erkannt. Öffne ein Pokémon und tippe erneut.")

        // Level-Bogen
        var levelHint: Double? = null
        if (s.useArc && s.arcCalibrated) {
            ImageAnalysis.arcDot(bmp, s.arcCy, s.arcR)?.let { d ->
                val f = ArcMath.fractionFromDot(d.x, d.y, bmp.width, bmp.height, s.arcCy)
                levelHint = ArcMath.levelFromFraction(g, f, s.trainerLevel)
            }
        }
        val cpNow = parsed.cp; val hpNow = parsed.hp; val hasAppraisal = appraisal != null
        val forced = prev?.let { pv -> pv.outcome.species?.takeIf { pv.outcome.parsed.cp == cpNow && pv.outcome.parsed.hp == hpNow && hasAppraisal } }
        var out = ScanEngine.resolve(g, parsed, s.scanSettings(), forced, levelHint, s.origin.floor, appraisal ?: Appraisal())
        if (appraisal != null && out.results.isEmpty()) {
            // Balken falsch gelesen? ohne Bewertung erneut
            out = ScanEngine.resolve(g, parsed, s.scanSettings(), forced, levelHint, s.origin.floor)
            appraisal = null
        }
        // Automatische Bogen-Kalibrierung, sobald das Level eindeutig ist
        val levels = out.results.map { it.level }.distinct()
        if (s.useArc && levels.size == 1 && appraisal == null) {
            val fit = arcFit(g, bmp, levels[0])
            if (fit != null) withContext(Dispatchers.Main) { applyArcFit(fit) }
        }
        return OverlayUi.Result(out, null, appraisal, levelHint)
    }

    private fun arcFit(g: GameData, bmp: Bitmap, level: Double): Pair<Float, Float>? {
        val s = Repo.settings
        val f = ArcMath.fraction(g, level, s.trainerLevel)
        if (abs(cos(PI * f)) < 0.3) return null
        val dots = ImageAnalysis.findWhiteDots(bmp)
        val fits = dots.mapNotNull { ArcMath.calibrate(it.x, it.y, bmp.width, bmp.height, f) }
        val fit = when {
            s.arcCalibrated -> fits.minByOrNull { abs(it.first - s.arcCy) + abs(it.second - s.arcR) }
                ?.takeIf { abs(it.first - s.arcCy) < 0.03f && abs(it.second - s.arcR) < 0.03f }
            fits.size == 1 -> fits[0]
            else -> null
        }
        return fit
    }

    private fun applyArcFit(fit: Pair<Float, Float>) {
        val n = minOf(Repo.settings.arcSamples, 19)
        Repo.updateSettings {
            it.copy(
                arcCy = if (n == 0) fit.first else (it.arcCy * n + fit.first) / (n + 1),
                arcR = if (n == 0) fit.second else (it.arcR * n + fit.second) / (n + 1),
                arcSamples = it.arcSamples + 1,
            )
        }
    }

    // ------------------------------------------------------------------ Auto-Scan (Stapel-Scan)

    fun toggleAutoScan() {
        if (autoJob?.isActive == true) {
            autoJob?.cancel(); Repo.autoScanActive = false; bubbleBadge = null
            Toast.makeText(this, "Auto-Scan aus", Toast.LENGTH_SHORT).show()
            return
        }
        val g = grabber ?: return
        Toast.makeText(this, "Auto-Scan an – einfach durch deine Pokémon wischen", Toast.LENGTH_LONG).show()
        hidePanel()
        Repo.autoScanActive = true
        autoJob = lifecycleScope.launch {
            var lastKey = ""
            var count = 0
            while (isActive) {
                val data = Repo.gameData
                val bmp = if (data != null) g.grab() else null
                if (data != null && bmp != null) {
                    val res = withContext(Dispatchers.Default) {
                        val lines = runCatching { Ocr.lines(bmp) }.getOrNull()
                        if (lines == null) null else {
                            val parsed = ScanParser.parse(lines, bmp.width, bmp.height, ScanParser.validDustValues(data))
                            val key = "${parsed.cp}|${parsed.hp}|${parsed.name}|${parsed.dust}"
                            if (!parsed.isPokemonScreen || key == lastKey) null
                            else {
                                lastKey = key
                                var hint: Double? = null
                                val s = Repo.settings
                                if (s.useArc && s.arcCalibrated) ImageAnalysis.arcDot(bmp, s.arcCy, s.arcR)?.let { d ->
                                    hint = ArcMath.levelFromFraction(data, ArcMath.fractionFromDot(d.x, d.y, bmp.width, bmp.height, s.arcCy), s.trainerLevel)
                                }
                                ScanEngine.resolve(data, parsed, s.scanSettings(), null, hint, s.origin.floor)
                            }
                        }
                    }
                    bmp.recycle()
                    if (res != null && res.results.isNotEmpty() && res.species != null) {
                        Repo.saveScan(res)
                        count++
                        val sum = res.results.summary()!!
                        bubbleBadge = "${Math.round(sum.minPct)}%" + if (sum.exact) "" else "+"
                    }
                }
                delay(Repo.settings.autoScanIntervalMs)
            }
        }
    }

    // ------------------------------------------------------------------ Benachrichtigung

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Scanner-Overlay", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val scan = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_SCAN), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_scan)
            .setContentTitle("IVisor-Scanner aktiv")
            .setContentText("Blase antippen zum Scannen · lang drücken für Auto-Scan")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Scannen", scan).build())
            .addAction(Notification.Action.Builder(null, "Beenden", stop).build())
            .build()
    }
}
