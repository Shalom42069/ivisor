package de.marlon.ivisor.scan

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.view.WindowManager
import kotlinx.coroutines.delay

/**
 * Hält eine dauerhafte VirtualDisplay-Sitzung (ab Android 14 darf ein Projection-Token nur
 * einmal verwendet werden) und liefert auf Anfrage das aktuelle Bild.
 */
class ScreenGrabber(private val ctx: Context, private val projection: MediaProjection, private val onStop: () -> Unit) {
    private val thread = HandlerThread("ivisor-capture").apply { start() }
    private val handler = Handler(thread.looper)
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    var width = 0; private set
    var height = 0; private set

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() { release(); onStop() }
        override fun onCapturedContentResize(w: Int, h: Int) {
            // z. B. wenn der Nutzer nur eine einzelne App teilt – Puffer anpassen
            if (w > 0 && h > 0 && (w != width || h != height)) handler.post { recreate(w, h) }
        }
    }

    @SuppressLint("WrongConstant")
    fun start() {
        projection.registerCallback(callback, handler)
        val wm = ctx.getSystemService(WindowManager::class.java)
        val b = wm.maximumWindowMetrics.bounds
        width = b.width(); height = b.height()
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3).also { it.setOnImageAvailableListener(listener, handler) }
        display = projection.createVirtualDisplay(
            "IVisorCapture", width, height, ctx.resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler,
        )
    }

    @SuppressLint("WrongConstant")
    private fun recreate(w: Int, h: Int) {
        width = w; height = h
        val old = reader
        synchronized(lock) { latest?.close(); latest = null }
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3).also { it.setOnImageAvailableListener(listener, handler) }
        display?.resize(w, h, ctx.resources.displayMetrics.densityDpi)
        display?.surface = reader!!.surface
        old?.close()
    }

    private val lock = Any()
    private var latest: android.media.Image? = null
    @Volatile private var latestAt = 0L

    private val listener = ImageReader.OnImageAvailableListener { rd ->
        val img = runCatching { rd.acquireLatestImage() }.getOrNull() ?: return@OnImageAvailableListener
        synchronized(lock) { latest?.close(); latest = img; latestAt = System.nanoTime() }
    }

    /**
     * Liefert das aktuelle Bild. Mit [freshAfterMs] > 0 wird auf ein Bild gewartet, das nach
     * dem Aufruf entstanden ist (z. B. nachdem das Overlay ausgeblendet wurde). Bei statischem
     * Bildschirm wird nach Timeout das letzte vorhandene Bild genommen.
     */
    suspend fun grab(freshAfterMs: Long = 0): Bitmap? {
        val t0 = System.nanoTime() + freshAfterMs * 1_000_000
        if (freshAfterMs > 0) {
            delay(freshAfterMs)
            var waited = 0
            while (latestAt < t0 && waited < 500) { delay(25); waited += 25 }
        }
        synchronized(lock) {
            val img = latest ?: return null
            return runCatching {
                val plane = img.planes[0]
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * img.width
                val buf = plane.buffer; buf.rewind()
                val tmp = Bitmap.createBitmap(img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888)
                tmp.copyPixelsFromBuffer(buf)
                if (rowPadding == 0) tmp else Bitmap.createBitmap(tmp, 0, 0, img.width, img.height).also { tmp.recycle() }
            }.getOrNull()
        }
    }

    fun release() {
        synchronized(lock) { latest?.close(); latest = null }
        runCatching { display?.release() }; display = null
        runCatching { reader?.close() }; reader = null
        runCatching { projection.unregisterCallback(callback) }
        thread.quitSafely()
    }
}
