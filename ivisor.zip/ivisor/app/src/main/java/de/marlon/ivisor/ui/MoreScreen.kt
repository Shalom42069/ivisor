package de.marlon.ivisor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import de.marlon.ivisor.core.*
import de.marlon.ivisor.data.Repo
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun MoreScreen() {
    val s = Repo.settings
    val g = Repo.gameData
    val scope = rememberCoroutineScope()
    var updating by remember { mutableStateOf(false) }
    var updateMsg by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Mehr", style = MaterialTheme.typography.headlineMedium)

        Panel {
            SectionTitle("Spitznamen-Vorlage")
            OutlinedTextField(
                value = s.nameTemplate, onValueChange = { v -> Repo.updateSettings { it.copy(nameTemplate = v) } },
                singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
            )
            val preview = NameGen.generate(s.nameTemplate, NameGen.Ctx(Ivs(15, 14, 13), 31.5, "Glurak", mapOf(League.GREAT to 7, League.ULTRA to 42), s.rankThreshold))
            Text("Vorschau: $preview", Modifier.padding(top = 6.dp), fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("{IV}{ADSc}", "{IV}{ADS}", "{IV}%{SL}{HL}", "{ADSc}{SL}", "{IV}★{LV}", "{Ab}{Db}{Sb}").forEach { t ->
                    AssistChip(onClick = { Repo.updateSettings { it.copy(nameTemplate = t) } }, label = { Text(t) })
                }
            }
            Text(
                "Platzhalter: {IV} {IV%} {A}{D}{S} {ADS} (hex) · {Ac}{Dc}{Sc} {ADSc} (⓪–⑮) · {Ab}{Db}{Sb} (fett) · {LV} · {★} · {SL}{HL}{LC}{ML} (Rang, nur ≤ Schwelle) · {NAME}. Max. 12 Zeichen.",
                color = C.textDim, fontSize = 12.sp,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Rang-Schwelle für Namen", Modifier.weight(1f))
                ChipRow(listOf(10, 50, 100, 500), s.rankThreshold, { "≤$it" }, { v -> Repo.updateSettings { it.copy(rankThreshold = v) } })
            }
        }

        Panel {
            SectionTitle("Scanner")
            Toggle("Scans automatisch speichern", s.autoSave) { v -> Repo.updateSettings { it.copy(autoSave = v) } }
            Toggle("Bewertungsbalken automatisch lesen", s.autoAppraisal) { v -> Repo.updateSettings { it.copy(autoAppraisal = v) } }
            Toggle("Level-Bogen nutzen", s.useArc) { v -> Repo.updateSettings { it.copy(useArc = v) } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (s.arcCalibrated) "Bogen kalibriert (${s.arcSamples}×)" else "Bogen nicht kalibriert", Modifier.weight(1f), color = C.textDim, fontSize = 13.sp)
                TextButton(onClick = { Repo.updateSettings { it.copy(arcSamples = 0, arcCy = -1f, arcR = -1f) } }) { Text("Zurücksetzen") }
            }
            Text("Auto-Scan-Intervall: ${s.autoScanIntervalMs} ms", fontSize = 14.sp)
            Slider(value = s.autoScanIntervalMs.toFloat(), onValueChange = { v -> Repo.updateSettings { it.copy(autoScanIntervalMs = (v / 100).roundToInt() * 100L) } }, valueRange = 500f..3000f)
            Text("Panel-Deckkraft: ${(s.panelAlpha * 100).roundToInt()}%", fontSize = 14.sp)
            Slider(value = s.panelAlpha, onValueChange = { v -> Repo.updateSettings { it.copy(panelAlpha = v) } }, valueRange = 0.6f..1f)
        }

        Panel {
            SectionTitle("Anzeige & PvP")
            Toggle("Deutsche Namen", s.germanNames) { v -> Repo.updateSettings { it.copy(germanNames = v) } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("PvP-Maximallevel", Modifier.weight(1f))
                ChipRow(listOf(40.0, 50.0, 51.0), s.pvpMaxLevel, { if (it == 51.0) "51 (Buddy)" else formatLevel(it) }, { v -> Repo.updateSettings { it.copy(pvpMaxLevel = v) } })
            }
        }

        g?.let { TypeChartCard(it) }

        Panel {
            SectionTitle("Spieldaten")
            Text("Stand: ${g?.version ?: "–"} · ${g?.pokemon?.size ?: 0} Pokémon · ${g?.moves?.size ?: 0} Attacken", fontSize = 13.sp)
            Text("Quelle: PvPoke (Werte, Attacken, Ranglisten) & PokeMiners-Gamemaster (Raid-Werte, deutsche Namen).", color = C.textDim, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !updating && g != null, onClick = {
                    updating = true; updateMsg = null
                    scope.launch {
                        val r = Repo.updateFromInternet()
                        updateMsg = r.fold({ "Aktualisiert: $it" }, { "Fehler: ${it.message}" })
                        updating = false
                    }
                }) { Text(if (updating) "Lade …" else "Jetzt aktualisieren") }
                OutlinedButton(onClick = { Repo.resetData(); updateMsg = "Auf mitgelieferte Daten zurückgesetzt" }) { Text("Zurücksetzen") }
            }
            updateMsg?.let { Text(it, Modifier.padding(top = 6.dp), fontSize = 12.sp, color = if (it.startsWith("Fehler")) C.bad else C.good) }
        }

        Panel {
            SectionTitle("Über")
            Text("IVisor 1.0 – freier IV-Scanner. Keine Werbung, keine Paywall, keine Konten, alles läuft lokal auf deinem Gerät.", fontSize = 13.sp)
            Text("Pokémon und Pokémon GO sind Marken von Nintendo/Creatures/GAME FREAK/Niantic. Inoffizielle Fan-App.", color = C.textDim, fontSize = 11.sp)
        }
    }
}

@Composable
private fun Toggle(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}

@Composable
private fun TypeChartCard(g: GameData) {
    var def1 by remember { mutableIntStateOf(g.typeIndex("dragon")) }
    var def2 by remember { mutableIntStateOf(-1) }
    Panel {
        SectionTitle("Typen-Tabelle")
        Text("Verteidiger-Typ(en) wählen:", color = C.textDim, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            g.types.indices.forEach { t ->
                val sel = t == def1 || t == def2
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(C.type(g.types[t]).copy(alpha = if (sel) 1f else 0.35f))
                        .border(if (sel) 2.dp else 0.dp, Color.White, RoundedCornerShape(50))
                        .clickable {
                            when {
                                t == def1 -> { def1 = if (def2 >= 0) def2 else def1; def2 = -1 }
                                t == def2 -> { def2 = -1 }
                                def2 < 0 -> { def2 = t }
                                else -> { def1 = def2; def2 = t }
                            }
                        }
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                ) { Text(Repo.typeName(t), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
        Spacer(Modifier.height(10.dp))
        val defTypes = listOfNotNull(def1.takeIf { it >= 0 }, def2.takeIf { it >= 0 })
        val eff = g.types.indices.map { it to g.effectiveness(it, defTypes) }
        val groups = listOf(
            "Sehr effektiv" to eff.filter { it.second > 1.001 }.sortedByDescending { it.second },
            "Nicht sehr effektiv" to eff.filter { it.second < 0.999 }.sortedBy { it.second },
        )
        groups.forEach { (title, list) ->
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            FlowRowCompat(list) { t, e ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(2.dp)) {
                    TypeChip(g, t)
                    Text(" ×${"%.3f".format(e).trimEnd('0').trimEnd('.')}", fontSize = 11.sp, color = C.textDim)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Angriff: Typ × Verteidiger (Zeile = Angreifer)", color = C.textDim, fontSize = 11.sp)
        MatrixView(g)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FlowRowCompat(items: List<Pair<Int, Double>>, cell: @Composable (Int, Double) -> Unit) {
    FlowRow(Modifier.fillMaxWidth()) { items.forEach { (t, e) -> cell(t, e) } }
}

@Composable
private fun MatrixView(g: GameData) {
    val n = g.types.size
    Column(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp)) {
        Row {
            Box(Modifier.size(28.dp))
            for (d in 0 until n) Box(Modifier.size(22.dp).background(C.type(g.types[d])), contentAlignment = Alignment.Center) {
                Text(Repo.typeName(d).take(2), fontSize = 8.sp, color = Color.White)
            }
        }
        for (a in 0 until n) Row {
            Box(Modifier.size(28.dp, 22.dp).background(C.type(g.types[a])), contentAlignment = Alignment.Center) {
                Text(Repo.typeName(a).take(3), fontSize = 8.sp, color = Color.White)
            }
            for (d in 0 until n) {
                val e = g.chart[a][d]
                val col = when { e > 1.001 -> C.good; e < 0.5 -> C.bad; e < 0.999 -> C.warn; else -> C.surface2 }
                Box(Modifier.size(22.dp).padding(1.dp).background(col.copy(alpha = if (e == 1.0) 1f else 0.8f)), contentAlignment = Alignment.Center) {
                    Text(if (e > 1.001) "+" else if (e < 0.5) "×" else if (e < 0.999) "−" else "", fontSize = 10.sp, textAlign = TextAlign.Center, color = Color.Black)
                }
            }
        }
    }
}
