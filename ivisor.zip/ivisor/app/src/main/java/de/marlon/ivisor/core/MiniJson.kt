package de.marlon.ivisor.core

/**
 * Kleiner, abhängigkeitsfreier JSON-Parser/-Writer.
 * Liefert Map<String, Any?>, List<Any?>, String, Double, Boolean oder null.
 */
object MiniJson {
    fun parse(text: String): Any? = Parser(text).run {
        skipWs(); val v = value(); skipWs(); v
    }

    private class Parser(val s: String) {
        var i = 0
        fun skipWs() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun value(): Any? {
            skipWs()
            if (i >= s.length) error("Unerwartetes Ende")
            return when (val c = s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> { expect("true"); true }
                'f' -> { expect("false"); false }
                'n' -> { expect("null"); null }
                else -> if (c == '-' || c.isDigit()) num() else error("Unerwartetes Zeichen '$c' bei $i")
            }
        }
        fun expect(w: String) { if (!s.startsWith(w, i)) error("Erwartet $w bei $i"); i += w.length }
        fun obj(): Map<String, Any?> {
            val m = LinkedHashMap<String, Any?>(); i++
            skipWs(); if (s[i] == '}') { i++; return m }
            while (true) {
                skipWs(); val k = str(); skipWs()
                if (s[i] != ':') error("':' erwartet bei $i"); i++
                m[k] = value(); skipWs()
                when (s[i]) { ',' -> i++; '}' -> { i++; return m }; else -> error("',' oder '}' erwartet bei $i") }
            }
        }
        fun arr(): List<Any?> {
            val l = ArrayList<Any?>(); i++
            skipWs(); if (s[i] == ']') { i++; return l }
            while (true) {
                l.add(value()); skipWs()
                when (s[i]) { ',' -> i++; ']' -> { i++; return l }; else -> error("',' oder ']' erwartet bei $i") }
            }
        }
        fun str(): String {
            if (s[i] != '"') error("String erwartet bei $i"); i++
            val sb = StringBuilder()
            while (true) {
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        when (val e = s[i++]) {
                            'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r')
                            'b' -> sb.append('\b'); 'f' -> sb.append('\u000C')
                            'u' -> { sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }
                            else -> sb.append(e)
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }
        fun num(): Double {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++
            return s.substring(st, i).toDouble()
        }
    }

    fun write(v: Any?): String = StringBuilder().also { w(it, v) }.toString()

    private fun w(sb: StringBuilder, v: Any?) {
        when (v) {
            null -> sb.append("null")
            is String -> {
                sb.append('"')
                for (c in v) when (c) {
                    '"' -> sb.append("\\\""); '\\' -> sb.append("\\\\"); '\n' -> sb.append("\\n")
                    '\r' -> sb.append("\\r"); '\t' -> sb.append("\\t")
                    else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
                }
                sb.append('"')
            }
            is Boolean -> sb.append(v)
            is Int, is Long -> sb.append(v)
            is Number -> { val d = v.toDouble(); if (d == Math.floor(d) && Math.abs(d) < 1e15) sb.append(d.toLong()) else sb.append(d) }
            is Map<*, *> -> {
                sb.append('{'); var first = true
                for ((k, x) in v) { if (!first) sb.append(','); first = false; w(sb, k.toString()); sb.append(':'); w(sb, x) }
                sb.append('}')
            }
            is Iterable<*> -> {
                sb.append('['); var first = true
                for (x in v) { if (!first) sb.append(','); first = false; w(sb, x) }
                sb.append(']')
            }
            is IntArray -> w(sb, v.toList())
            is DoubleArray -> w(sb, v.toList())
            else -> w(sb, v.toString())
        }
    }
}

@Suppress("UNCHECKED_CAST")
internal fun Any?.obj(): Map<String, Any?> = this as Map<String, Any?>
@Suppress("UNCHECKED_CAST")
internal fun Any?.arr(): List<Any?> = this as List<Any?>
internal fun Any?.int(): Int = (this as Number).toInt()
internal fun Any?.dbl(): Double = (this as Number).toDouble()
