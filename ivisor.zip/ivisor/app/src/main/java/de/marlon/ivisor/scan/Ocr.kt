package de.marlon.ivisor.scan

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import de.marlon.ivisor.core.OcrLine
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Texterkennung komplett auf dem Gerät (ML Kit, gebündeltes Latin-Modell). */
object Ocr {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    suspend fun lines(bitmap: Bitmap): List<OcrLine> = suspendCancellableCoroutine { cont ->
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { text ->
                val out = ArrayList<OcrLine>()
                for (b in text.textBlocks) for (l in b.lines) {
                    val r = l.boundingBox ?: continue
                    out.add(OcrLine(l.text, r.left, r.top, r.right, r.bottom))
                }
                if (cont.isActive) cont.resume(out)
            }
            .addOnFailureListener { e -> if (cont.isActive) cont.resumeWithException(e) }
    }
}
