package de.marlon.ivisor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import de.marlon.ivisor.core.*
import de.marlon.ivisor.data.Repo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun RaidScreen() {
    val g = Repo.gameData ?: run { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return }
    var boss by remember { mutableStateOf(g.byId["groudon"]) }
    var tier by remember { mutableStateOf(RaidTier.T5) }
    var weather by remember { mutableStateOf(Weather.NONE) }
    var level by remember { mutableDoubleStateOf(40.0) }
    var shadow by remember { mutableStateOf(true) }
    var mega by remember { mutableStateOf(true) }
    var legendary by remember { mutableStateOf(true) }
    var ownedOnly by remember { mutableStateOf(false) }
    val owned = remember(Repo.records) { Repo.records.map { it.pokemonId }.toSet() }
    val ownedFamilies = remember(owned, g) { owned.mapNotNull { g.byId[it] }.flatMap { listOf(it) + g.evolutionsOf(it) }.map { it.id }.toSet() }

    val counters by produceState<List<Counter>?>(null, boss, tier, weather, level, shadow, mega, legendary, g) {
        value = null
        val b = boss ?: return@produceState
        value = withContext(Dispatchers.Default) {
            RaidCalculator.counters(g, b, RaidOptions(tier, level, 15, weather, shadow, mega, legendary), limit = 200)
        }
    }

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Raid-Konter", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Panel {
                PokemonPicker(g, boss, { boss = it }, label = "Raid-Boss")
                Spacer(Modifier.height(8.dp))
                ChipRow(RaidTier.entries, tier, { it.label }, { tier = it })
                Spacer(Modifier.height(4.dp))
                ChipRow(Weather.entries, weather, { it.label }, { weather = it })
                Spacer(Modifier.height(4.dp))
                ChipRow(listOf(30.0, 40.0, 45.0, 50.0), level, { "Lv ${formatLevel(it)}" }, { level = it })
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = shadow, onClick = { shadow = !shadow }, label = { Text("Crypto") })
                    FilterChip(selected = mega, onClick = { mega = !mega }, label = { Text("Mega") })
                    FilterChip(selected = legendary, onClick = { legendary = !legendary }, label = { Text("Legendär") })
                    FilterChip(selected = ownedOnly, onClick = { ownedOnly = !ownedOnly }, label = { Text("Meine") })
                }
            }
        }
        boss?.let { b ->
            item { BossInfo(g, b, tier) }
        }
        val list = counters
        if (list == null) item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        else {
            val shown = (if (ownedOnly) list.filter { it.pokemon.id in ownedFamilies } else list).take(40)
            if (shown.isEmpty()) item { Text(if (ownedOnly) "Keine passenden Konter in deiner Sammlung (inkl. Entwicklungen)." else "Keine Konter gefunden.", color = C.textDim) }
            val top = list.firstOrNull()?.score ?: 1.0
            itemsIndexed(shown, key = { _, c -> c.pokemon.id + c.shadow }) { i, c -> CounterRow(g, i + 1, c, top, c.pokemon.id in ownedFamilies) }
        }
    }
}

@Composable
private fun BossInfo(g: GameData, b: Pokemon, tier: RaidTier) {
    val weak = remember(b.id) {
        g.types.indices.map { it to g.effectiveness(it, b.types) }.filter { it.second > 1.0 }.sortedByDescending { it.second }
    }
    val (c20, c25) = remember(b.id) { RaidCalculator.catchCp(g, b) }
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(Repo.name(b), style = MaterialTheme.typography.titleLarge)
                Row { b.types.forEach { TypeChip(g, it); Spacer(Modifier.width(4.dp)) } }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Boss-WP ${fmt(RaidCalculator.bossCp(b, tier))}", fontWeight = FontWeight.Bold)
                Text("${fmt(tier.hp)} KP", color = C.textDim, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Schwächen", color = C.textDim, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            weak.take(6).forEach { (t, e) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    TypeChip(g, t); Text("×${"%.2f".format(e).trimEnd('0').trimEnd('.')}", fontSize = 10.sp, color = C.textDim)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Fang-WP: ${c20.first}–${c20.last} · mit Wetter ${c25.first}–${c25.last} (100%: ${c20.last} / ${c25.last})", fontSize = 13.sp)
    }
}

@Composable
private fun CounterRow(g: GameData, place: Int, c: Counter, top: Double, owned: Boolean) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.surface).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("$place", Modifier.width(28.dp), color = if (place <= 3) C.gold else C.textDim, fontWeight = FontWeight.Black)
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text((if (c.shadow) "Crypto-" else "") + Repo.name(c.pokemon), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (owned) { Spacer(Modifier.width(6.dp)); Pill("Sammlung", C.good) }
            }
            Text(
                "${Repo.moveName(c.fast)}${if (c.fast.id in c.pokemon.elite) "*" else ""} · ${Repo.moveName(c.charged)}${if (c.charged.id in c.pokemon.elite) "*" else ""}",
                color = C.textDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(progress = { (c.score / top).toFloat() }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)), color = C.type(g.types[c.charged.type]), trackColor = C.surface2)
        }
        Spacer(Modifier.width(10.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text("%.1f".format(c.dps), fontWeight = FontWeight.Bold)
            Text("DPS", color = C.textDim, fontSize = 10.sp)
            Text("TDO %.0f".format(c.tdo), color = C.textDim, fontSize = 10.sp)
        }
    }
}
