package de.marlon.ivisor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.ClipData
import android.content.ClipboardManager
import de.marlon.ivisor.core.*
import de.marlon.ivisor.data.Repo
import kotlin.math.roundToInt

@Composable
fun CalcScreen() {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text("Rechner", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(start = 16.dp, top = 12.dp))
        TabRow(selectedTabIndex = tab, containerColor = C.bg, modifier = Modifier.padding(top = 6.dp)) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("IV") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("PvP") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Power-Up") })
        }
        val g = Repo.gameData
        if (g == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        else when (tab) {
            0 -> IvCalc(g)
            1 -> PvpCalc(g)
            else -> PowerCalc(g)
        }
    }
}

private enum class VariantSel(val label: String, val set: Set<Variant>?) {
    AUTO("Auto", null), NORMAL("Normal", setOf(Variant.NORMAL)), SHADOW("Crypto", setOf(Variant.SHADOW)),
    PURIFIED("Erlöst", setOf(Variant.PURIFIED)), LUCKY("Glücks", setOf(Variant.LUCKY, Variant.LUCKY_PURIFIED)),
}

@Composable
private fun IvCalc(g: GameData) {
    val ctx = LocalContext.current
    var species by remember { mutableStateOf<Pokemon?>(null) }
    var cp by remember { mutableStateOf("") }
    var hp by remember { mutableStateOf("") }
    var dust by remember { mutableStateOf("") }
    var variant by remember { mutableStateOf(VariantSel.AUTO) }
    var origin by remember { mutableStateOf(Repo.settings.origin) }
    var stars by remember { mutableStateOf<Int?>(null) }
    var barA by remember { mutableStateOf<Int?>(null) }
    var barD by remember { mutableStateOf<Int?>(null) }
    var barS by remember { mutableStateOf<Int?>(null) }
    var saved by remember { mutableStateOf(false) }

    LaunchedEffect(species, cp, hp, dust, variant, origin, stars, barA, barD, barS) { saved = false }
    val results = remember(species, cp, hp, dust, variant, origin, stars, barA, barD, barS) {
        val p = species; val c = cp.toIntOrNull()
        if (p == null || c == null) null
        else {
            val set = variant.set ?: if (dust.isBlank()) setOf(Variant.NORMAL) else Variant.entries.toSet()
            IvCalculator.calculate(g, ScanInput(
                p, c, hp.toIntOrNull(), dust.toIntOrNull(), variants = set, ivFloor = origin.floor,
                appraisal = Appraisal(
                    barA?.let { Appraisal.barRange(it) } ?: 0..15, barD?.let { Appraisal.barRange(it) } ?: 0..15,
                    barS?.let { Appraisal.barRange(it) } ?: 0..15, stars,
                ),
                maxLevel = g.maxLevel,
            ))
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel {
            PokemonPicker(g, species, { species = it })
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("WP", cp, { cp = it }, Modifier.weight(1f))
                NumberField("KP (max)", hp, { hp = it }, Modifier.weight(1f))
                NumberField("Staub", dust, { dust = it }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Text("Variante", color = C.textDim, fontSize = 12.sp)
            ChipRow(VariantSel.entries, variant, { it.label }, { variant = it })
            Text("Herkunft", color = C.textDim, fontSize = 12.sp)
            ChipRow(Origin.entries, origin, { it.label }, { origin = it })
        }
        Panel {
            SectionTitle("Bewertung (optional)")
            Text("Sterne", color = C.textDim, fontSize = 12.sp)
            ChipRow(listOf(null, 0, 1, 2, 3, 4), stars, { it?.let { n -> "$n★" } ?: "egal" }, { stars = it })
            val segLabel: (Int?) -> String = { when (it) { null -> "?"; 0 -> "leer"; 4 -> "voll"; else -> "$it/3" } }
            Text("Angriff-Balken", color = C.textDim, fontSize = 12.sp)
            ChipRow(listOf(null, 0, 1, 2, 3, 4), barA, segLabel, { barA = it })
            Text("Verteidigung-Balken", color = C.textDim, fontSize = 12.sp)
            ChipRow(listOf(null, 0, 1, 2, 3, 4), barD, segLabel, { barD = it })
            Text("KP-Balken", color = C.textDim, fontSize = 12.sp)
            ChipRow(listOf(null, 0, 1, 2, 3, 4), barS, segLabel, { barS = it })
        }
        val p = species
        when {
            p == null || results == null -> Text("Art und WP eingeben – das Ergebnis erscheint sofort.", color = C.textDim)
            results.isEmpty() -> Panel { Text("Keine passende Kombination. Werte, Variante oder Herkunft prüfen.", color = C.warn) }
            else -> Panel {
                ResultHeader(g, p, results, cp.toIntOrNull(), hp.toIntOrNull())
                Spacer(Modifier.height(10.dp))
                IvBars(results)
                Spacer(Modifier.height(10.dp))
                val nick = Repo.nicknameFor(g, p, results.minBy { it.ivs.total })
                NicknameRow(nick) { ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Name", nick)) }
                Spacer(Modifier.height(10.dp))
                SectionTitle("PvP-Ränge")
                PvpTableView(g, p, results, Repo.settings.pvpMaxLevel)
                Spacer(Modifier.height(10.dp))
                SectionTitle("Kombinationen")
                ComboList(results, 25)
                Spacer(Modifier.height(10.dp))
                GradientButton(if (saved) "Gespeichert ✓" else "In Sammlung speichern", Modifier.fillMaxWidth(), enabled = !saved) {
                    Repo.saveScan(ScanOutcome(ParsedScreen(cp = cp.toIntOrNull(), hp = hp.toIntOrNull(), dust = dust.toIntOrNull(), isPokemonScreen = true), p, listOf(p), results, 1.0))
                    saved = true
                }
            }
        }
    }
}

@Composable
private fun IvSlider(label: String, v: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(40.dp), color = C.textDim, fontSize = 13.sp)
        Slider(value = v.toFloat(), onValueChange = { onChange(it.roundToInt()) }, valueRange = 0f..15f, steps = 14, modifier = Modifier.weight(1f))
        Text("$v", Modifier.width(28.dp), fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PvpCalc(g: GameData) {
    var species by remember { mutableStateOf<Pokemon?>(g.byId["medicham"]) }
    var a by remember { mutableIntStateOf(0) }
    var d by remember { mutableIntStateOf(15) }
    var s by remember { mutableIntStateOf(15) }
    var league by remember { mutableStateOf(League.GREAT) }
    val maxL = Repo.settings.pvpMaxLevel
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel {
            PokemonPicker(g, species, { species = it })
            Spacer(Modifier.height(8.dp))
            IvSlider("ANG", a) { a = it }; IvSlider("VER", d) { d = it }; IvSlider("KP", s) { s = it }
            ChipRow(League.entries, league, { it.label }, { league = it })
        }
        species?.let { p -> PvpResult(g, p, Ivs(a, d, s), league, maxL) }
    }
}

@Composable
private fun PvpResult(g: GameData, p: Pokemon, iv: Ivs, league: League, maxL: Double) {
    var shadow by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        val table = remember(p.id, league, maxL) { PvpCalculator.table(g, p, league, maxL) }
        val e = table.of(iv)!!
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(Repo.name(p), style = MaterialTheme.typography.titleLarge)
                    Text("${league.label} · IV $iv", color = C.textDim, fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("#${e.rank}", fontSize = 30.sp, fontWeight = FontWeight.Black, color = C.rank(e.rank))
                    Text("von 4096", color = C.textDim, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Stat("Stat-Produkt", "${"%.2f".format(e.percentOfBest)}%")
                Stat("Level", formatLevel(e.level))
                Stat("WP", "${e.cp}")
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Stat("Angriff", "%.1f".format(e.atk)); Stat("Verteid.", "%.1f".format(e.def)); Stat("KP", "${e.hp}")
            }
            if (!table.relevant) Text("Hinweis: ${Repo.name(p)} erreicht das Liga-Limit nicht – der Rang ist wenig aussagekräftig.", color = C.warn, fontSize = 12.sp)
        }
        // Meta & Moveset
        val meta = g.meta(league, p.id, shadow) ?: g.meta(league, p.id)
        Panel {
            SectionTitle("Meta (PvPoke)")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (meta != null) "Platz ${meta.place} · Score ${"%.1f".format(meta.score)}" else "Nicht in der Rangliste", Modifier.weight(1f))
                if (p.flags and Flags.SHADOW_ELIGIBLE != 0) FilterChip(selected = shadow, onClick = { shadow = !shadow }, label = { Text("Crypto") })
            }
            val ms = meta?.moveset?.mapNotNull { g.moves[it] }
            if (!ms.isNullOrEmpty() && ms.size >= 2) {
                val fast = ms[0]
                Spacer(Modifier.height(6.dp))
                Text("Empfohlen: ${ms.joinToString(" / ") { Repo.moveName(it) }}", fontSize = 13.sp)
                ms.drop(1).forEach { c ->
                    val counts = PvpCalculator.moveCounts(fast, c)
                    Text("${Repo.moveName(c)} (${c.pvpEnergy} E): ${counts.joinToString("-")} ${Repo.moveName(fast)}", color = C.textDim, fontSize = 12.sp)
                }
            }
        }
        Panel {
            SectionTitle("Top 10 IVs")
            table.entries.take(10).forEach { t ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(8.dp)).background(if (t.ivs == iv) C.accent.copy(alpha = 0.25f) else C.surface2).padding(6.dp)) {
                    Text("#${t.rank}", Modifier.weight(0.6f), fontWeight = FontWeight.Bold, color = C.rank(t.rank), fontSize = 13.sp)
                    Text("${t.ivs}", Modifier.weight(1f), fontSize = 13.sp)
                    Text("L${formatLevel(t.level)}", Modifier.weight(0.7f), fontSize = 13.sp)
                    Text("WP ${t.cp}", Modifier.weight(0.9f), fontSize = 13.sp)
                    Text("${"%.1f".format(t.percentOfBest)}%", Modifier.weight(0.8f), fontSize = 13.sp, color = C.textDim)
                }
            }
        }
        Panel {
            SectionTitle("Alle Ligen")
            League.entries.forEach { l ->
                val t = PvpCalculator.table(g, p, l, maxL)
                val x = t.of(iv)!!
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Text(l.label, Modifier.weight(1.3f))
                    Text("#${x.rank}", Modifier.weight(0.8f), color = if (t.relevant) C.rank(x.rank) else C.textDim, fontWeight = FontWeight.Bold)
                    Text("WP ${x.cp}", Modifier.weight(1f), color = C.textDim)
                    Text("L${formatLevel(x.level)}", Modifier.weight(0.7f), color = C.textDim)
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, color = C.textDim, fontSize = 11.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
private fun PowerCalc(g: GameData) {
    var from by remember { mutableFloatStateOf(20f) }
    var to by remember { mutableFloatStateOf(40f) }
    var variant by remember { mutableStateOf(Variant.NORMAL) }
    val f = (from * 2).roundToInt() / 2.0
    val t = (to * 2).roundToInt() / 2.0
    val c = PowerUp.cost(g, f, maxOf(f, t), variant)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel {
            Text("Von Level ${formatLevel(f)}", fontWeight = FontWeight.SemiBold)
            Slider(value = from, onValueChange = { from = it }, valueRange = 1f..50f, steps = 97)
            Text("Auf Level ${formatLevel(t)}", fontWeight = FontWeight.SemiBold)
            Slider(value = to, onValueChange = { to = it }, valueRange = 1f..50f, steps = 97)
            ChipRow(listOf(Variant.NORMAL, Variant.SHADOW, Variant.PURIFIED, Variant.LUCKY), variant, { it.label }, { variant = it })
        }
        Panel {
            SectionTitle("Kosten")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Stat("Sternenstaub", fmt(c.stardust)); Stat("Bonbons", "${c.candy}"); Stat("XL-Bonbons", "${c.xlCandy}")
            }
            Text("${c.steps} Power-Ups", color = C.textDim, fontSize = 12.sp)
        }
    }
}
