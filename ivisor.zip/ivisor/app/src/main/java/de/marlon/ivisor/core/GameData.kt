package de.marlon.ivisor.core

import kotlin.math.floor
import kotlin.math.sqrt

object Flags {
    const val LEGENDARY = 1
    const val MYTHICAL = 2
    const val SHADOW_ELIGIBLE = 4
    const val MEGA = 8
    const val ULTRA_BEAST = 16
    const val UNTRADEABLE = 32
}

data class Pokemon(
    val id: String,
    val dex: Int,
    val name: String,
    val nameDe: String,
    val atk: Int,
    val def: Int,
    val sta: Int,
    val types: List<Int>,
    val fast: List<String>,
    val charged: List<String>,
    val flags: Int,
    val evolutions: List<String>,
    val parent: String?,
    val family: String?,
    val elite: List<String>,
) {
    val isMega get() = flags and Flags.MEGA != 0
    val isLegendary get() = flags and (Flags.LEGENDARY or Flags.MYTHICAL or Flags.ULTRA_BEAST) != 0
    fun display(german: Boolean) = if (german) nameDe else name
}

/** PvPoke-Meta-Eintrag: Score 0–100, Platz und empfohlenes Moveset. */
data class MetaEntry(val speciesId: String, val score: Double, val place: Int, val moveset: List<String>)

data class Move(
    val id: String,
    val name: String,
    val nameDe: String,
    val type: Int,
    val fast: Boolean,
    val pvpPower: Double,
    val pvpEnergy: Int,
    val turns: Int,
    val buffs: List<Int>?,
    val buffTarget: String?,
    val buffChance: Double,
    val pvePower: Double,
    val pveDurationMs: Int,
    val pveEnergy: Int,
    val pveWindowMs: Int,
    val pveEstimated: Boolean,
) {
    fun display(german: Boolean) = if (german) nameDe else name
}

class GameData(
    val version: String,
    val pokemon: List<Pokemon>,
    val moves: Map<String, Move>,
    val types: List<String>,
    val typesDe: List<String>,
    val chart: Array<DoubleArray>,
    private val cpmFull: DoubleArray,
    private val dust: IntArray,
    private val candy: IntArray,
    private val xl: IntArray,
    val shadowDustMult: Double,
    val shadowCandyMult: Double,
    val purifiedDustMult: Double,
    val purifiedCandyMult: Double,
    val maxPowerUpLevel: Int,
    /** Liga-Cap (500/1500/2500/10000) → speciesId (inkl. "_shadow") → Meta-Eintrag */
    val meta: Map<Int, Map<String, MetaEntry>> = emptyMap(),
) {
    fun meta(league: League, id: String, shadow: Boolean = false): MetaEntry? =
        meta[if (league == League.MASTER) 10000 else league.cap]?.get(if (shadow) "${id}_shadow" else id)

    val byId: Map<String, Pokemon> = pokemon.associateBy { it.id }

    /** Höchstes Level inkl. Best-Buddy-Boost. */
    val maxLevel: Double get() = maxPowerUpLevel + 1.0

    /** Alle Halblevel von 1.0 bis maxLevel. */
    val levels: List<Double> = (0..((maxPowerUpLevel + 1 - 1) * 2)).map { 1.0 + it * 0.5 }

    private val cpmCache = HashMap<Double, Double>()

    fun cpm(level: Double): Double = cpmCache.getOrPut(level) {
        val l = floor(level).toInt()
        require(l >= 1 && l <= cpmFull.size) { "Ungültiges Level $level" }
        if (level == l.toDouble()) cpmFull[l - 1]
        else {
            val a = cpmFull[l - 1]; val b = cpmFull[minOf(l, cpmFull.size - 1)]
            sqrt((a * a + b * b) / 2.0)
        }
    }

    /** Sternenstaubkosten, um von [level] eine Halbstufe hochzuleveln (ohne Multiplikator). */
    fun dustCost(level: Double): Int? {
        if (level >= maxPowerUpLevel) return null
        val i = floor(level).toInt() - 1
        return dust.getOrNull(i)
    }

    /** Bonbonkosten (normal, XL) für eine Halbstufe ab [level]. */
    fun candyCost(level: Double): Pair<Int, Int>? {
        if (level >= maxPowerUpLevel) return null
        val l = floor(level).toInt()
        return if (l < 40) Pair(candy.getOrElse(l - 1) { 0 }, 0)
        else Pair(0, xl.getOrElse(l - 40) { 0 })
    }

    fun typeIndex(name: String): Int = types.indexOf(name.lowercase())
    fun typeName(i: Int, german: Boolean) = if (german) typesDe[i] else types[i].replaceFirstChar { it.uppercase() }

    fun effectiveness(attackType: Int, defTypes: List<Int>): Double =
        defTypes.fold(1.0) { acc, t -> acc * chart[attackType][t] }

    fun family(p: Pokemon): List<Pokemon> =
        if (p.family == null) listOf(p) else pokemon.filter { it.family == p.family && !it.isMega }

    /** Alle Weiterentwicklungen (rekursiv), ohne Megas. */
    fun evolutionsOf(p: Pokemon): List<Pokemon> {
        val out = ArrayList<Pokemon>(); val seen = HashSet<String>()
        fun rec(x: Pokemon) {
            for (e in x.evolutions) {
                val q = byId[e] ?: continue
                if (seen.add(q.id) && !q.isMega) { out.add(q); rec(q) }
            }
        }
        rec(p); return out
    }

    fun search(query: String, limit: Int = 30): List<Pokemon> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return pokemon.take(limit)
        q.toIntOrNull()?.let { n -> return pokemon.filter { it.dex == n } }
        val starts = pokemon.filter { it.nameDe.lowercase().startsWith(q) || it.name.lowercase().startsWith(q) || it.id.startsWith(q) }
        val contains = pokemon.filter { it !in starts && (it.nameDe.lowercase().contains(q) || it.name.lowercase().contains(q)) }
        return (starts + contains).take(limit)
    }

    fun copyWith(
        version: String = this.version, pokemon: List<Pokemon> = this.pokemon, moves: Map<String, Move> = this.moves,
        meta: Map<Int, Map<String, MetaEntry>> = this.meta,
    ) = GameData(
        version, pokemon, moves, types, typesDe, chart, cpmFull, dust, candy, xl, shadowDustMult, shadowCandyMult,
        purifiedDustMult, purifiedCandyMult, maxPowerUpLevel, meta,
    )

    companion object {
        fun parse(text: String): GameData {
            val root = MiniJson.parse(text).obj()
            val types = root["types"].arr().map { it as String }
            val tIdx = types.withIndex().associate { it.value to it.index }
            val moves = LinkedHashMap<String, Move>()
            for (mv in root["moves"].arr()) {
                val m = mv.obj()
                val id = m["id"] as String
                moves[id] = moveFrom(m, tIdx)
            }
            val mons = root["pokemon"].arr().map { po ->
                val p = po.obj()
                Pokemon(
                    id = p["id"] as String, dex = p["dx"].int(), name = p["n"] as String, nameDe = p["nd"] as String,
                    atk = p["a"].int(), def = p["d"].int(), sta = p["s"].int(),
                    types = p["t"].arr().mapNotNull { tIdx[it as String] },
                    fast = p["fm"].arr().map { it as String }, charged = p["cm"].arr().map { it as String },
                    flags = (p["fl"] as? Number)?.toInt() ?: 0,
                    evolutions = (p["ev"] as? List<*>)?.map { it as String } ?: emptyList(),
                    parent = p["pa"] as? String, family = p["fa"] as? String,
                    elite = (p["el"] as? List<*>)?.map { it as String } ?: emptyList(),
                )
            }
            val mult = root["mult"].obj()
            return GameData(
                version = root["version"] as? String ?: "",
                pokemon = mons, moves = moves, types = types,
                typesDe = root["typesDe"].arr().map { it as String },
                chart = root["chart"].arr().map { r -> r.arr().map { it.dbl() }.toDoubleArray() }.toTypedArray(),
                cpmFull = root["cpm"].arr().map { it.dbl() }.toDoubleArray(),
                dust = root["dust"].arr().map { it.int() }.toIntArray(),
                candy = root["candy"].arr().map { it.int() }.toIntArray(),
                xl = root["xl"].arr().map { it.int() }.toIntArray(),
                shadowDustMult = mult["shadowDust"].dbl(), shadowCandyMult = mult["shadowCandy"].dbl(),
                purifiedDustMult = mult["purDust"].dbl(), purifiedCandyMult = mult["purCandy"].dbl(),
                maxPowerUpLevel = root["maxLevel"].int(),
                meta = parseMeta(root["meta"]),
            )
        }

        private fun parseMeta(m: Any?): Map<Int, Map<String, MetaEntry>> {
            if (m !is Map<*, *>) return emptyMap()
            return m.entries.associate { (k, v) ->
                (k as String).toInt() to (v as List<*>).withIndex().associate { (i, e) ->
                    val l = e as List<*>
                    val id = l[0] as String
                    id to MetaEntry(id, (l[1] as Number).toDouble(), i + 1, l.drop(2).map { it as String })
                }
            }
        }

        /** Übernimmt eine frische PvPoke-Rangliste (rankings-XXXX.json). */
        fun withRankings(old: GameData, cap: Int, json: String): GameData {
            val list = MiniJson.parse(json).arr()
            val entries = list.withIndex().associate { (i, e) ->
                val o = e.obj(); val id = o["speciesId"] as String
                id to MetaEntry(id, (o["score"] as Number).toDouble(), i + 1, (o["moveset"] as? List<*>)?.map { it as String } ?: emptyList())
            }
            val meta = old.meta.toMutableMap(); meta[cap] = entries
            return old.copyWith(meta = meta)
        }

        private fun moveFrom(m: Map<String, Any?>, tIdx: Map<String, Int>): Move {
            val fast = m["f"].int() == 1
            val pp = m["pp"].dbl(); val pe = m["pe"].int()
            val hasPve = m.containsKey("ep")
            return Move(
                id = m["id"] as String, name = m["n"] as String, nameDe = m["nd"] as String,
                type = tIdx[m["t"] as String] ?: 0, fast = fast, pvpPower = pp, pvpEnergy = pe,
                turns = (m["tu"] as? Number)?.toInt() ?: 1,
                buffs = (m["bf"] as? List<*>)?.map { it.int() }, buffTarget = m["bt"] as? String,
                buffChance = (m["bc"] as? Number)?.toDouble() ?: 1.0,
                pvePower = if (hasPve) m["ep"].dbl() else pp,
                pveDurationMs = if (hasPve) m["ed"].int() else if (fast) 500 * ((m["tu"] as? Number)?.toInt() ?: 1) else 2500,
                pveEnergy = if (hasPve) m["ee"].int() else if (fast) pe else pe,
                pveWindowMs = if (hasPve) m["ew"].int() else 0,
                pveEstimated = !hasPve,
            )
        }

        /**
         * Aktualisiert Basiswerte/Attacken aus einem frischen PvPoke-Gamemaster.
         * Deutsche Namen und PvE-Werte werden aus den vorhandenen Daten übernommen.
         */
        fun mergePvpoke(old: GameData, pvpokeJson: String): GameData {
            val root = MiniJson.parse(pvpokeJson).obj()
            val tIdx = old.types.withIndex().associate { it.value to it.index }
            val moves = LinkedHashMap(old.moves)
            for (mv in root["moves"].arr()) {
                val m = mv.obj()
                val id = m["moveId"] as String
                val eg = m["energyGain"].int(); val en = m["energy"].int()
                val fast = eg > 0 || en == 0
                val prev = old.moves[id]
                val pp = m["power"].dbl(); val pe = if (fast) eg else en
                @Suppress("UNCHECKED_CAST")
                val buffs = (m["buffs"] as? List<Any?>)?.map { it.int() }
                val base = prev ?: Move(
                    id, m["name"] as String, m["name"] as String, tIdx[m["type"] as String] ?: 0, fast, pp, pe,
                    (m["turns"] as? Number)?.toInt() ?: 1, null, null, 1.0, pp,
                    if (fast) 500 * ((m["turns"] as? Number)?.toInt() ?: 1) else 2500, pe, 0, true,
                )
                moves[id] = base.copy(
                    name = m["name"] as String, type = tIdx[m["type"] as String] ?: base.type, fast = fast,
                    pvpPower = pp, pvpEnergy = pe, turns = (m["turns"] as? Number)?.toInt() ?: 1,
                    buffs = buffs, buffTarget = m["buffTarget"] as? String,
                    buffChance = (m["buffApplyChance"] as? String)?.toDoubleOrNull() ?: (m["buffApplyChance"] as? Number)?.toDouble() ?: 1.0,
                )
            }
            val oldById = old.byId
            val deByDex = old.pokemon.groupBy { it.dex }.mapValues { e -> e.value.minByOrNull { it.nameDe.length }!!.nameDe.substringBefore(" (") }
            val mons = ArrayList<Pokemon>()
            for (po in root["pokemon"].arr()) {
                val p = po.obj()
                @Suppress("UNCHECKED_CAST")
                val tags = (p["tags"] as? List<Any?>)?.map { it as String } ?: emptyList()
                val id = p["speciesId"] as String
                if ("shadow" in tags || "duplicate" in tags || id.endsWith("_shadow") || p["released"] == false) continue
                val b = p["baseStats"].obj()
                val dex = p["dex"].int()
                val nm = p["speciesName"] as String
                val prev = oldById[id]
                var fl = 0
                if ("legendary" in tags) fl = fl or Flags.LEGENDARY
                if ("mythical" in tags) fl = fl or Flags.MYTHICAL
                if ("shadoweligible" in tags) fl = fl or Flags.SHADOW_ELIGIBLE
                if ("mega" in tags || "supermega" in tags || id.contains("_mega") || id.endsWith("_primal")) fl = fl or Flags.MEGA
                if ("ultrabeast" in tags) fl = fl or Flags.ULTRA_BEAST
                if ("untradeable" in tags) fl = fl or Flags.UNTRADEABLE
                val fam = p["family"] as? Map<*, *>
                val form = Regex("\\((.*)\\)$").find(nm)?.groupValues?.get(1)
                val de = prev?.nameDe ?: deByDex[dex]?.let { if (form != null) "$it ($form)" else it } ?: nm
                mons.add(
                    Pokemon(
                        id, dex, nm, de, b["atk"].int(), b["def"].int(), b["hp"].int(),
                        p["types"].arr().mapNotNull { tIdx[it as String] },
                        p["fastMoves"].arr().map { it as String }, p["chargedMoves"].arr().map { it as String },
                        fl, (fam?.get("evolutions") as? List<*>)?.map { it as String } ?: emptyList(),
                        fam?.get("parent") as? String, fam?.get("id") as? String,
                        (p["elite"] as? List<*>)?.map { it as String } ?: emptyList(),
                    )
                )
            }
            return old.copyWith(version = root["timestamp"] as? String ?: old.version, pokemon = mons, moves = moves)
        }
    }
}
