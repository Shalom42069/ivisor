package de.marlon.ivisor

import android.app.Application
import de.marlon.ivisor.data.Repo

class IVisorApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Repo.init(this)
    }
}
