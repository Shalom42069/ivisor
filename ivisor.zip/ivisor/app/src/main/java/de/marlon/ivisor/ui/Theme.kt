package de.marlon.ivisor.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object C {
    val bg = Color(0xFF0E1016)
    val surface = Color(0xFF171A23)
    val surface2 = Color(0xFF1F2330)
    val outline = Color(0xFF2C3242)
    val text = Color(0xFFECEEF5)
    val textDim = Color(0xFF9AA1B5)
    val accent = Color(0xFF7C5CFF)
    val accent2 = Color(0xFFFF5C8A)
    val good = Color(0xFF3DDC97)
    val warn = Color(0xFFFFB547)
    val bad = Color(0xFFFF6B6B)
    val gold = Color(0xFFFFD34D)

    val accentBrush = Brush.linearGradient(listOf(accent, accent2))

    /** Farbe je IV-Prozent (orientiert an der Spielbewertung). */
    fun iv(pct: Double): Color = when {
        pct >= 100.0 -> Color(0xFFFF4D7E)
        pct >= 82.2 -> Color(0xFFFF9F43)
        pct >= 66.6 -> Color(0xFFFFD34D)
        pct >= 51.1 -> Color(0xFF6BD6A4)
        else -> Color(0xFF8A93A8)
    }

    fun rank(rank: Int?): Color = when {
        rank == null -> textDim
        rank <= 10 -> Color(0xFFFF4D7E)
        rank <= 50 -> Color(0xFFFF9F43)
        rank <= 100 -> Color(0xFFFFD34D)
        rank <= 500 -> Color(0xFF6BD6A4)
        else -> textDim
    }

    private val typeColors = mapOf(
        "normal" to 0xFFA8A77A, "fighting" to 0xFFC22E28, "flying" to 0xFFA98FF3, "poison" to 0xFFA33EA1,
        "ground" to 0xFFE2BF65, "rock" to 0xFFB6A136, "bug" to 0xFFA6B91A, "ghost" to 0xFF735797,
        "steel" to 0xFFB7B7CE, "fire" to 0xFFEE8130, "water" to 0xFF6390F0, "grass" to 0xFF7AC74C,
        "electric" to 0xFFF7D02C, "psychic" to 0xFFF95587, "ice" to 0xFF96D9D6, "dragon" to 0xFF6F35FC,
        "dark" to 0xFF705746, "fairy" to 0xFFD685AD,
    )
    fun type(name: String): Color = Color(typeColors[name] ?: 0xFF888888)
}

private val scheme = darkColorScheme(
    primary = C.accent, onPrimary = Color.White, secondary = C.accent2, onSecondary = Color.White,
    background = C.bg, onBackground = C.text, surface = C.surface, onSurface = C.text,
    surfaceVariant = C.surface2, onSurfaceVariant = C.textDim, outline = C.outline,
    surfaceContainer = C.surface, surfaceContainerHigh = C.surface2, surfaceContainerHighest = C.surface2,
    surfaceContainerLow = C.surface, surfaceContainerLowest = C.bg, error = C.bad,
)

private val typo = Typography(
    headlineMedium = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 15.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun IVisorTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typo, content = content)
}
