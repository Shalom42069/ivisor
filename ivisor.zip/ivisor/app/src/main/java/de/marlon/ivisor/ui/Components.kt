package de.marlon.ivisor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import de.marlon.ivisor.core.*
import de.marlon.ivisor.data.Repo
import kotlin.math.roundToInt

@Composable
fun Panel(modifier: Modifier = Modifier, padding: Dp = 14.dp, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(C.surface)
            .border(1.dp, C.outline.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(padding),
        content = content,
    )
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text.uppercase(), modifier.padding(bottom = 8.dp), color = C.textDim, style = MaterialTheme.typography.labelMedium, letterSpacing = 1.2.sp)
}

/** Runder IV-Badge mit Prozent (oder Spanne). */
@Composable
fun IvBadge(minPct: Double, maxPct: Double, size: Dp = 56.dp) {
    val lo = minPct.roundToInt(); val hi = maxPct.roundToInt()
    val col = C.iv(minPct)
    Box(
        Modifier.size(size).clip(CircleShape).background(col.copy(alpha = 0.18f)).border(2.dp, col, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            if (lo == hi) "$hi" else "$lo-$hi",
            color = col, fontWeight = FontWeight.Bold,
            fontSize = if (lo == hi) (size.value * 0.34f).sp else (size.value * 0.22f).sp,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun Stars(n: Int, size: Dp = 14.dp) {
    Row {
        repeat(4) { i ->
            Text(if (i < n) "★" else "☆", color = if (n == 4) Color(0xFFFF4D7E) else if (i < n) C.gold else C.outline, fontSize = size.value.sp)
        }
    }
}

/** Segmentierter Balken 0–15 wie in der Spielbewertung, zeigt Bereich an. */
@Composable
fun StatBar(label: String, range: IntRange, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(34.dp), color = C.textDim, style = MaterialTheme.typography.labelMedium)
        Row(Modifier.weight(1f).height(10.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            for (seg in 0 until 3) {
                Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(3.dp)).background(C.surface2)) {
                    val segMin = seg * 5
                    val fillLo = ((range.first - segMin).coerceIn(0, 5)) / 5f
                    val fillHi = ((range.last - segMin).coerceIn(0, 5)) / 5f
                    val full = range.first == 15
                    Box(Modifier.fillMaxHeight().fillMaxWidth(fillHi).background(if (full) Color(0xFFFF4D7E).copy(alpha = 0.45f) else C.warn.copy(alpha = 0.35f)))
                    Box(Modifier.fillMaxHeight().fillMaxWidth(fillLo).background(if (full) Color(0xFFFF4D7E) else C.warn))
                }
            }
        }
        Text(
            if (range.first == range.last) "${range.first}" else "${range.first}-${range.last}",
            Modifier.width(44.dp), textAlign = TextAlign.End, fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
fun TypeChip(g: GameData, t: Int) {
    val name = g.types[t]
    Box(Modifier.clip(RoundedCornerShape(50)).background(C.type(name)).padding(horizontal = 8.dp, vertical = 2.dp)) {
        Text(Repo.typeName(t), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Pill(text: String, color: Color = C.accent, modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f)).padding(horizontal = 9.dp, vertical = 3.dp)) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(16.dp))
            .background(if (enabled) C.accentBrush else androidx.compose.ui.graphics.SolidColor(C.surface2))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold) }
}

@Composable
fun NumberField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value, onValueChange = { v -> onChange(v.filter { it.isDigit() }.take(6)) },
        label = { Text(label) }, singleLine = true, modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        shape = RoundedCornerShape(14.dp),
    )
}

/** Suchfeld mit Vorschlagsliste für Pokémon. */
@Composable
fun PokemonPicker(g: GameData, selected: Pokemon?, onSelect: (Pokemon) -> Unit, modifier: Modifier = Modifier, label: String = "Pokémon", maxListHeight: Dp = 260.dp, onFocus: ((Boolean) -> Unit)? = null) {
    var query by remember(selected?.id) { mutableStateOf(selected?.let { Repo.name(it) } ?: "") }
    var open by remember { mutableStateOf(false) }
    Column(modifier) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it; open = true; onFocus?.invoke(true) },
            label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = ""; open = true; onFocus?.invoke(true) }) { Icon(Icons.Default.Clear, null) } },
            shape = RoundedCornerShape(14.dp),
        )
        if (open && query.isNotBlank() && query != selected?.let { Repo.name(it) }) {
            val list = remember(query, g) { g.search(query, 40) }
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = maxListHeight).padding(top = 4.dp).clip(RoundedCornerShape(14.dp)).background(C.surface2)) {
                items(list, key = { it.id }) { p ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(p); query = Repo.name(p); open = false; onFocus?.invoke(false) }.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("#${p.dex}", color = C.textDim, modifier = Modifier.width(48.dp), fontSize = 12.sp)
                        Text(Repo.name(p), Modifier.weight(1f))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { p.types.forEach { TypeChip(g, it) } }
                    }
                }
            }
        }
    }
}

@Composable
fun <T> ChipRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { o ->
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) }, shape = RoundedCornerShape(50))
        }
    }
}
