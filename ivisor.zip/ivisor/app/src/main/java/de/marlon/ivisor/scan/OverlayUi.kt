package de.marlon.ivisor.scan

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import de.marlon.ivisor.core.*
import de.marlon.ivisor.data.Repo
import de.marlon.ivisor.ui.C
import de.marlon.ivisor.ui.ComboList
import de.marlon.ivisor.ui.IVisorTheme
import de.marlon.ivisor.ui.IvBars
import de.marlon.ivisor.ui.NicknameRow
import de.marlon.ivisor.ui.Pill
import de.marlon.ivisor.ui.PokemonPicker
import de.marlon.ivisor.ui.PowerUpView
import de.marlon.ivisor.ui.PvpTableView
import de.marlon.ivisor.ui.ResultHeader
import de.marlon.ivisor.ui.SectionTitle

@Composable
fun Bubble(service: OverlayService, onTap: () -> Unit, onLongPress: () -> Unit, onDrag: (Float, Float) -> Unit, onDragEnd: () -> Unit) {
    IVisorTheme {
        val auto = Repo.autoScanActive
        Box(Modifier.padding(6.dp), contentAlignment = Alignment.TopEnd) {
            Box(
                Modifier
                    .size(58.dp)
                    .shadow(10.dp, CircleShape)
                    .clip(CircleShape)
                    .background(C.accentBrush)
                    .border(3.dp, if (auto) C.good else Color.White.copy(alpha = 0.85f), CircleShape)
                    .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }, onLongPress = { onLongPress() }) }
                    .pointerInput(Unit) {
                        detectDragGestures(onDragEnd = onDragEnd) { change, amount -> change.consume(); onDrag(amount.x, amount.y) }
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (service.bubbleBusy) CircularProgressIndicator(Modifier.size(28.dp), color = Color.White, strokeWidth = 3.dp)
                else Icon(Icons.Default.Visibility, "Scannen", tint = Color.White, modifier = Modifier.size(28.dp))
            }
            service.bubbleBadge?.let { b ->
                Box(Modifier.offset(x = 4.dp, y = (-4).dp).clip(RoundedCornerShape(50)).background(C.good).padding(horizontal = 5.dp, vertical = 1.dp)) {
                    Text(b, color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ResultPanel(service: OverlayService) {
    IVisorTheme {
        val maxH = (LocalConfiguration.current.screenHeightDp * 0.68f).dp
        Box(
            Modifier
                .fillMaxWidth()
                .heightIn(max = maxH)
                .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                .background(C.bg.copy(alpha = 0.97f))
                .border(1.dp, C.outline, RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                .animateContentSize(),
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.align(Alignment.CenterHorizontally).size(40.dp, 4.dp).clip(RoundedCornerShape(2.dp)).background(C.outline))
                when (val st = service.ui) {
                    OverlayUi.Hidden -> {}
                    OverlayUi.Scanning -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(22.dp)); Spacer(Modifier.width(12.dp)); Text("Scanne …")
                    }
                    is OverlayUi.Error -> ErrorContent(service, st.message)
                    is OverlayUi.Result -> ResultContent(service, st)
                }
            }
        }
    }
}

@Composable
private fun ErrorContent(service: OverlayService, msg: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(msg, Modifier.weight(1f))
        IconButton(onClick = { service.hidePanel() }) { Icon(Icons.Default.Close, "Schließen") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { service.scan() }) { Text("Erneut scannen") }
        OutlinedButton(onClick = { service.openApp() }) { Text("App öffnen") }
    }
}

@Composable
private fun ResultContent(service: OverlayService, st: OverlayUi.Result) {
    val g = Repo.gameData ?: return
    val out = st.outcome
    val p = out.species
    var picking by remember { mutableStateOf(p == null) }
    var showCombos by remember { mutableStateOf(false) }
    var showPower by remember { mutableStateOf(false) }

    if (p != null) {
        ResultHeader(g, p, out.results, out.parsed.cp, out.parsed.hp) {
            IconButton(onClick = { service.hidePanel() }) { Icon(Icons.Default.Close, "Schließen") }
        }
    } else {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("WP ${out.parsed.cp ?: "?"} · KP ${out.parsed.hp ?: "?"}", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = { service.hidePanel() }) { Icon(Icons.Default.Close, "Schließen") }
        }
    }
    out.message?.let { Text(it, color = C.warn) }

    // Artwahl
    if (out.alternatives.size > 1 || picking) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            out.alternatives.take(4).forEach { a ->
                FilterChip(selected = a.id == p?.id, onClick = { service.recompute(a) }, label = { Text(Repo.name(a), maxLines = 1) })
            }
        }
    }
    if (picking) {
        PokemonPicker(g, p, onSelect = { service.recompute(it); picking = false; service.updatePanelFocus(false) }, label = "Art wählen",
            maxListHeight = 180.dp, onFocus = { f -> if (f) service.updatePanelFocus(true) })
    } else {
        Text("Falsche Art? Hier tippen", color = C.accent, fontSize = 13.sp, modifier = Modifier.clickable { picking = true; service.updatePanelFocus(true) })
    }

    if (p == null || out.results.isEmpty()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { service.scan() }) { Text("Erneut scannen") }
        }
        return
    }

    IvBars(out.results)
    if (st.appraisal != null) Pill("Bewertung eingerechnet", C.good)
    if (st.levelHint != null) Text("Level-Bogen: ~${formatLevel(st.levelHint)}", color = C.textDim, fontSize = 12.sp)
    if (out.results.map { it.ivs }.distinct().size > 1)
        Text("Tipp: Bewertung im Spiel öffnen und nochmal scannen – die Balken werden automatisch eingerechnet.", color = C.textDim, fontSize = 12.sp)

    val nick = remember(out.results, p.id) { Repo.nicknameFor(g, p, out.results.minBy { it.ivs.total }) }
    NicknameRow(nick) { service.copy(nick) }

    SectionTitle("PvP-Ränge")
    PvpTableView(g, p, out.results, Repo.settings.pvpMaxLevel)

    TextButton(onClick = { showCombos = !showCombos }) { Text(if (showCombos) "IV-Kombinationen ausblenden" else "Alle IV-Kombinationen (${out.results.size})") }
    if (showCombos) ComboList(out.results, 40)
    TextButton(onClick = { showPower = !showPower }) { Text(if (showPower) "Power-Up ausblenden" else "Power-Up-Kosten") }
    if (showPower) PowerUpView(g, p, out.results)

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { service.scan() }, Modifier.weight(1f)) { Text("Neu scannen") }
        if (st.record == null) OutlinedButton(onClick = { service.saveCurrent() }, Modifier.weight(1f)) { Text("Speichern") }
        else OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.weight(1f)) { Text("Gespeichert ✓") }
    }
}
