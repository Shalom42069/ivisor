package de.marlon.ivisor.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import de.marlon.ivisor.data.Repo
import de.marlon.ivisor.scan.OverlayService

enum class MainTab(val label: String, val icon: ImageVector) {
    SCAN("Scanner", Icons.Default.Visibility),
    COLLECTION("Sammlung", Icons.Default.CatchingPokemon),
    CALC("Rechner", Icons.Default.Calculate),
    RAID("Raid", Icons.Default.Groups),
    MORE("Mehr", Icons.Default.Tune),
}

class MainActivity : ComponentActivity() {
    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == RESULT_OK && data != null) {
            OverlayService.start(this, res.resultCode, data)
            Toast.makeText(this, "Overlay aktiv – öffne jetzt Pokémon GO", Toast.LENGTH_LONG).show()
            // Nach dem Start direkt zu Pokémon GO wechseln, falls installiert
            packageManager.getLaunchIntentForPackage("com.nianticlabs.pokemongo")?.let { startActivity(it) }
        } else Toast.makeText(this, "Bildschirmaufnahme wurde nicht erlaubt", Toast.LENGTH_SHORT).show()
    }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { startOverlayFlow() }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            IVisorTheme {
                var tab by rememberSaveable { mutableStateOf(MainTab.SCAN) }
                Scaffold(
                    containerColor = C.bg,
                    bottomBar = {
                        NavigationBar(containerColor = C.surface, tonalElevation = 0.dp) {
                            MainTab.entries.forEach { t ->
                                NavigationBarItem(
                                    selected = tab == t, onClick = { tab = t },
                                    icon = { Icon(t.icon, t.label) }, label = { Text(t.label) },
                                    colors = NavigationBarItemDefaults.colors(indicatorColor = C.accent.copy(alpha = 0.25f)),
                                )
                            }
                        }
                    },
                ) { pad ->
                    Box(Modifier.padding(pad).fillMaxSize()) {
                        when (tab) {
                            MainTab.SCAN -> ScanScreen(onStart = { startOverlayFlow() }, onStop = { OverlayService.stop(this@MainActivity) }, onOpenCollection = { tab = MainTab.COLLECTION })
                            MainTab.COLLECTION -> CollectionScreen(onShare = { shareCsv() })
                            MainTab.CALC -> CalcScreen()
                            MainTab.RAID -> RaidScreen()
                            MainTab.MORE -> MoreScreen()
                        }
                    }
                }
            }
        }
    }

    fun startOverlayFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Bitte „Über anderen Apps einblenden“ erlauben", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !notifAsked) {
            notifAsked = true
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private var notifAsked = false

    private fun shareCsv() {
        val f = Repo.exportCsv()
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.files", f)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Sammlung exportieren"))
    }
}
