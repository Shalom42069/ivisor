package de.marlon.ivisor.core

import kotlin.math.pow
import kotlin.math.roundToInt

/** Wie stark ist eine Weiterentwicklung eines gescannten Pokémon? */
data class EvoAdvice(
    val record: ScanRecord,
    val from: Pokemon,
    val target: Pokemon,
    val ivs: Ivs,
    val level: Double,
    val cpAfter: Int,
    val maxCp: Int,
    val glRank: Int?,
    val ulRank: Int?,
    val raidPercentile: Double,
    val masterPercentile: Double,
    val score: Double,
    val reasons: List<String>,
)

object EvolutionAdvisor {
    private var raidPct: Map<String, Double>? = null
    private var mlPct: Map<String, Double>? = null
    private var cachedVersion: String? = null

    /** Perzentil (0..1) der Raid-Angriffsstärke gegen einen neutralen Boss, einmal pro Datenstand berechnet. */
    @Synchronized
    fun ensureMeta(g: GameData) {
        if (cachedVersion == g.version && raidPct != null) return
        val dummy = Pokemon("_dummy", 0, "Dummy", "Dummy", 200, 200, 200, emptyList(), emptyList(), emptyList(), 0, emptyList(), null, null, emptyList())
        val bossDef = (200 + 15) * 0.79
        val cpm = g.cpm(40.0)
        val scores = HashMap<String, Double>()
        val ml = HashMap<String, Double>()
        for (p in g.pokemon) {
            if (p.isMega) continue
            val atk = Stats.attack(p, 15, cpm)
            var best = 0.0
            for (f in p.fast) { val fm = g.moves[f] ?: continue
                for (c in p.charged) { val cm = g.moves[c] ?: continue
                    val dps = RaidCalculator.cycleDps(g, p, fm, cm, atk, bossDef, dummy, emptySet(), 1.0)
                    val tdo = dps * Stats.hp(p, 15, cpm) / (900.0 / Stats.defense(p, 15, cpm))
                    val er = (dps.pow(3) * tdo).pow(0.25)
                    if (er > best) best = er
                } }
            scores[p.id] = best
            ml[p.id] = Stats.statProduct(p, Ivs(15, 15, 15), g.cpm(50.0))
        }
        raidPct = percentiles(scores); mlPct = percentiles(ml); cachedVersion = g.version
    }

    private fun percentiles(m: Map<String, Double>): Map<String, Double> {
        val sorted = m.entries.sortedBy { it.value }
        val n = (sorted.size - 1).coerceAtLeast(1)
        return sorted.withIndex().associate { it.value.key to it.index.toDouble() / n }
    }

    /**
     * Liefert Empfehlungen für alle Einträge mit mindestens [minStars] Sternen (bei unsicheren
     * IVs zählt die schlechteste mögliche Kombination), sortiert nach Score.
     */
    fun advise(g: GameData, records: List<ScanRecord>, minStars: Int = 3, pvpMaxLevel: Double = 50.0, bestOnly: Boolean = true): List<EvoAdvice> {
        ensureMeta(g)
        val out = ArrayList<EvoAdvice>()
        for (r in records) {
            if (r.results.isEmpty() || r.minStars < minStars) continue
            val from = g.byId[r.pokemonId] ?: continue
            val targets = g.evolutionsOf(from)
            if (targets.isEmpty()) continue
            // konservativ: schlechteste mögliche IV-Kombination verwenden
            val worst = r.results.minBy { it.ivs.total }
            for (t in targets) {
                val cpAfter = Stats.cp(g, t, worst.ivs, worst.level)
                val maxCp = Stats.cp(g, t, worst.ivs, 50.0)
                val glT = PvpCalculator.table(g, t, League.GREAT, pvpMaxLevel)
                val ulT = PvpCalculator.table(g, t, League.ULTRA, pvpMaxLevel)
                val gl = if (glT.relevant) glT.of(worst.ivs) else null
                val ul = if (ulT.relevant) ulT.of(worst.ivs) else null
                // Nur zählbar, wenn das aktuelle Level noch unter dem Liga-Level liegt
                val glRank = gl?.takeIf { it.level >= worst.level }?.rank
                val ulRank = ul?.takeIf { it.level >= worst.level }?.rank
                val raid = raidPct?.get(t.id) ?: 0.0
                val mlp = mlPct?.get(t.id) ?: 0.0
                val ivFactor = worst.ivs.percent / 100.0
                fun rankScore(rank: Int?) = if (rank == null || rank > 200) 0.0 else 1.0 - (rank - 1) / 400.0
                // Gewichtung mit PvPoke-Meta-Score der Zielart (unbekannt → schwach gewichtet)
                val shadow = worst.variant == Variant.SHADOW
                val glMeta = g.meta(League.GREAT, t.id, shadow) ?: g.meta(League.GREAT, t.id)
                val ulMeta = g.meta(League.ULTRA, t.id, shadow) ?: g.meta(League.ULTRA, t.id)
                fun metaW(m: MetaEntry?) = if (m == null) 0.3 else ((m.score - 50.0) / 45.0).coerceIn(0.0, 1.0).pow(1.5)
                val glS = rankScore(glRank) * metaW(glMeta); val ulS = rankScore(ulRank) * metaW(ulMeta)
                val raidS = raid.pow(2) * ivFactor
                val mlS = mlp.pow(2) * ivFactor
                val score = maxOf(glS * 0.95, ulS * 0.95, raidS, mlS * 0.9) * 100
                val reasons = ArrayList<String>()
                if (glRank != null && glRank <= 200) reasons.add("SL-Rang $glRank" + (glMeta?.let { " · Meta #${it.place}" } ?: ""))
                if (ulRank != null && ulRank <= 200) reasons.add("HL-Rang $ulRank" + (ulMeta?.let { " · Meta #${it.place}" } ?: ""))
                if (raid >= 0.8) reasons.add("Raid-Top ${((1 - raid) * 100).roundToInt().coerceAtLeast(1)}%")
                if (mlp >= 0.85) reasons.add("Meisterliga-tauglich")
                reasons.add("WP danach $cpAfter")
                out.add(EvoAdvice(r, from, t, worst.ivs, worst.level, cpAfter, maxCp, glRank, ulRank, raid, mlp, score, reasons))
            }
        }
        // pro Scan nur die beste Entwicklung behalten
        if (!bestOnly) return out.sortedByDescending { it.score }
        return out.groupBy { it.record.id }.map { e -> e.value.maxBy { it.score } }.sortedByDescending { it.score }
    }
}
