package de.marlon.ivisor.ui

import android.content.ClipData
import android.content.ClipboardManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import de.marlon.ivisor.core.*
import de.marlon.ivisor.data.Repo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class SortBy(val label: String) { IV("IV %"), CP("WP"), LEVEL("Level"), GL("SL-Rang"), UL("HL-Rang"), DATE("Datum"), NAME("Name"), DEX("Nr.") }
enum class StarFilter(val label: String, val min: Int) { ALL("Alle", 0), S1("≥1★", 1), S2("≥2★", 2), S3("≥3★", 3), S4("4★", 4) }

data class RankInfo(val gl: Int?, val ul: Int?, val lc: Int?)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectionScreen(onShare: () -> Unit) {
    val g = Repo.gameData
    var tab by remember { mutableIntStateOf(0) }
    var confirmClear by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<ScanRecord?>(null) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Sammlung", style = MaterialTheme.typography.headlineMedium)
                Text("${Repo.records.size} Pokémon gescannt", color = C.textDim, fontSize = 13.sp)
            }
            IconButton(onClick = onShare, enabled = Repo.records.isNotEmpty()) { Icon(Icons.Default.Share, "Exportieren") }
            IconButton(onClick = { confirmClear = true }, enabled = Repo.records.isNotEmpty()) { Icon(Icons.Default.DeleteSweep, "Alle löschen") }
        }
        TabRow(selectedTabIndex = tab, containerColor = C.bg, modifier = Modifier.padding(top = 6.dp)) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Alle") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Lohnt sich zu entwickeln") })
        }
        if (g == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else if (Repo.records.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text("Noch keine Scans. Starte das Overlay und tippe in Pokémon GO auf die Blase – jeder Scan landet hier.", color = C.textDim)
            }
        } else when (tab) {
            0 -> AllList(g) { detail = it }
            else -> EvolveList(g) { detail = it }
        }
    }

    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Alle Scans löschen?") },
        text = { Text("${Repo.records.size} Einträge werden entfernt.") },
        confirmButton = { TextButton(onClick = { Repo.clearRecords(); confirmClear = false }) { Text("Löschen", color = C.bad) } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Abbrechen") } },
    )

    detail?.let { r ->
        val current = Repo.records.firstOrNull { it.id == r.id }
        if (current != null && g != null) ModalBottomSheet(onDismissRequest = { detail = null }, containerColor = C.bg) {
            RecordDetail(g, current, onClose = { detail = null })
        }
    }
}

@Composable
private fun AllList(g: GameData, onOpen: (ScanRecord) -> Unit) {
    var query by rememberSaveableString()
    var sort by remember { mutableStateOf(SortBy.IV) }
    var desc by remember { mutableStateOf(true) }
    var stars by remember { mutableStateOf(StarFilter.ALL) }
    var favOnly by remember { mutableStateOf(false) }
    var exactOnly by remember { mutableStateOf(false) }
    val records = Repo.records
    val maxL = Repo.settings.pvpMaxLevel

    // PvP-Ränge im Hintergrund berechnen (beste Entwicklung der Familie)
    val ranks by produceState(initialValue = emptyMap<Long, RankInfo>(), records, maxL, g) {
        value = withContext(Dispatchers.Default) { records.associate { it.id to rankInfo(g, it, maxL) } }
    }

    val list = remember(records, query, sort, desc, stars, favOnly, exactOnly, ranks) {
        val q = query.trim().lowercase()
        records.asSequence()
            .filter { q.isEmpty() || (g.byId[it.pokemonId]?.let { p -> p.nameDe.lowercase().contains(q) || p.name.lowercase().contains(q) } ?: false) }
            .filter { it.minStars >= stars.min && (stars != StarFilter.S4 || it.minStars == 4) }
            .filter { !favOnly || it.favorite }
            .filter { !exactOnly || it.exact }
            .toList()
            .let { l ->
                val cmp: Comparator<ScanRecord> = when (sort) {
                    SortBy.IV -> compareBy<ScanRecord> { it.avgPct }
                    SortBy.CP -> compareBy<ScanRecord> { it.cp }
                    SortBy.LEVEL -> compareBy<ScanRecord> { it.results.maxOfOrNull { r -> r.level } ?: 0.0 }
                    SortBy.GL -> compareBy<ScanRecord> { -(ranks[it.id]?.gl ?: 99999) }
                    SortBy.UL -> compareBy<ScanRecord> { -(ranks[it.id]?.ul ?: 99999) }
                    SortBy.DATE -> compareBy<ScanRecord> { it.timestamp }
                    SortBy.NAME -> compareBy<ScanRecord> { g.byId[it.pokemonId]?.let { p -> Repo.name(p) } ?: "" }.let { c -> Comparator { a, b -> -c.compare(a, b) } }
                    SortBy.DEX -> compareBy<ScanRecord> { -(g.byId[it.pokemonId]?.dex ?: 0) }
                }
                if (desc) l.sortedWith(cmp.reversed()) else l.sortedWith(cmp)
            }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Suchen …") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(14.dp),
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                ChipRow(SortBy.entries, sort, { it.label }, { if (it == sort) { desc = !desc } else { sort = it; desc = true } }, Modifier.weight(1f))
                IconButton(onClick = { desc = !desc }) { Icon(if (desc) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, "Richtung") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                ChipRow(StarFilter.entries, stars, { it.label }, { stars = it }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = favOnly, onClick = { favOnly = !favOnly }, label = { Text("★ Favoriten") })
                FilterChip(selected = exactOnly, onClick = { exactOnly = !exactOnly }, label = { Text("Nur exakte IVs") })
                Text("${list.size} Treffer", color = C.textDim, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterVertically))
            }
        }
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(list, key = { _, r -> r.id }) { _, r -> RecordRow(g, r, ranks[r.id]) { onOpen(r) } }
        }
    }
}

@Composable
private fun rememberSaveableString(): MutableState<String> = androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf("") }

fun rankInfo(g: GameData, r: ScanRecord, maxL: Double): RankInfo {
    val p = g.byId[r.pokemonId] ?: return RankInfo(null, null, null)
    val fam = listOf(p) + g.evolutionsOf(p)
    fun best(l: League): Int? = fam.mapNotNull { t ->
        val table = PvpCalculator.table(g, t, l, maxL)
        if (!table.relevant) null
        else r.results.mapNotNull { res -> table.of(res.ivs)?.takeIf { it.level >= res.level }?.rank }.minOrNull()
    }.minOrNull()
    return RankInfo(best(League.GREAT), best(League.ULTRA), best(League.LITTLE))
}

@Composable
private fun RecordRow(g: GameData, r: ScanRecord, ranks: RankInfo?, onClick: () -> Unit) {
    val p = g.byId[r.pokemonId]
    Panel(padding = 10.dp, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IvBadge(r.minPct, r.maxPct, 48.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(Repo.name(p), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (r.favorite) Text(" ★", color = C.gold)
                    r.variant?.takeIf { it != Variant.NORMAL }?.let { Spacer(Modifier.width(6.dp)); Pill(it.label, if (it == Variant.SHADOW) C.accent else C.good) }
                    if (r.lucky && r.variant == null) { Spacer(Modifier.width(6.dp)); Pill("Glücks", C.gold) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("WP ${r.cp}" + (r.level?.let { " · Lv ${formatLevel(it)}" } ?: ""), color = C.textDim, fontSize = 12.sp)
                    Spacer(Modifier.width(8.dp)); Stars(r.minStars, 12.dp)
                    if (!r.exact) Text("  ${r.results.map { it.ivs }.distinct().size} Mögl.", color = C.textDim, fontSize = 11.sp)
                }
                if (r.exact) r.results.firstOrNull()?.let { Text("${it.ivs.atk} / ${it.ivs.def} / ${it.ivs.sta}", fontSize = 12.sp, color = C.text) }
            }
            Column(horizontalAlignment = Alignment.End) {
                ranks?.gl?.takeIf { it <= 500 }?.let { Text("SL #$it", color = C.rank(it), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                ranks?.ul?.takeIf { it <= 500 }?.let { Text("HL #$it", color = C.rank(it), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                ranks?.lc?.takeIf { it <= 100 }?.let { Text("LC #$it", color = C.rank(it), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun EvolveList(g: GameData, onOpen: (ScanRecord) -> Unit) {
    var minStars by remember { mutableIntStateOf(3) }
    val records = Repo.records
    val maxL = Repo.settings.pvpMaxLevel
    val advice by produceState<List<EvoAdvice>?>(initialValue = null, records, minStars, maxL, g) {
        value = null
        value = withContext(Dispatchers.Default) { EvolutionAdvisor.advise(g, records, minStars, maxL) }
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            Text("Pokémon ab ${minStars}★ mit Weiterentwicklung – sortiert danach, wie stark die Entwicklung wird (PvP-Rang × Meta, Raid-Stärke, Meisterliga).", color = C.textDim, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            ChipRow(listOf(3, 4), minStars, { if (it == 4) "Nur 4★" else "≥ 3★" }, { minStars = it })
        }
        val list = advice
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text("Keine gescannten Pokémon mit ≥ ${minStars}★, die sich noch entwickeln können.", color = C.textDim)
            }
            else -> LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(list, key = { _, a -> a.record.id }) { i, a -> AdviceRow(g, i + 1, a) { onOpen(a.record) } }
            }
        }
    }
}

@Composable
private fun AdviceRow(g: GameData, place: Int, a: EvoAdvice, onClick: () -> Unit) {
    Panel(padding = 12.dp, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("#$place", color = if (place <= 3) C.gold else C.textDim, fontWeight = FontWeight.Black, fontSize = 18.sp, modifier = Modifier.width(40.dp))
            IvBadge(a.record.minPct, a.record.maxPct, 46.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("${Repo.name(a.from)} → ${Repo.name(a.target)}", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Stars(a.record.minStars, 12.dp)
                    Text("  WP ${a.record.cp} → ${a.cpAfter}", color = C.textDim, fontSize = 12.sp)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${a.score.roundToInt()}", fontWeight = FontWeight.Black, fontSize = 20.sp, color = C.iv(a.score))
                Text("Score", color = C.textDim, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(progress = { (a.score / 100.0).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)), color = C.iv(a.score), trackColor = C.surface2)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            a.reasons.take(3).forEach { r -> Pill(r, if (r.startsWith("WP")) C.textDim else C.good) }
        }
    }
}

@Composable
fun RecordDetail(g: GameData, r: ScanRecord, onClose: () -> Unit) {
    val p = g.byId[r.pokemonId] ?: return
    val ctx = LocalContext.current
    val dateFmt = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY) }
    var confirmDelete by remember { mutableStateOf(false) }
    val evos = remember(r.id, r.results) { EvolutionAdvisor.advise(g, listOf(r), 0, Repo.settings.pvpMaxLevel, bestOnly = false) }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ResultHeader(g, p, r.results, r.cp, r.hp) {
            IconButton(onClick = { Repo.updateRecord(r.copy(favorite = !r.favorite)) }) {
                Icon(if (r.favorite) Icons.Default.Star else Icons.Default.StarBorder, "Favorit", tint = if (r.favorite) C.gold else C.textDim)
            }
        }
        Text("Gescannt am ${dateFmt.format(Date(r.timestamp))}" + (r.dust?.let { " · Staubkosten ${fmt(it)}" } ?: ""), color = C.textDim, fontSize = 12.sp)
        IvBars(r.results)
        Repo.nickname(r)?.let { n ->
            NicknameRow(n) {
                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Name", n))
            }
        }
        SectionTitle("PvP-Ränge")
        PvpTableView(g, p, r.results, Repo.settings.pvpMaxLevel)
        if (evos.isNotEmpty()) {
            SectionTitle("Entwicklungen")
            evos.forEach { a ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.surface2).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(Repo.name(a.target), fontWeight = FontWeight.SemiBold)
                        Text(a.reasons.joinToString(" · "), color = C.textDim, fontSize = 12.sp)
                    }
                    Text("${a.score.roundToInt()}", color = C.iv(a.score), fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
            }
        }
        SectionTitle("IV-Kombinationen")
        ComboList(r.results, 30)
        SectionTitle("Power-Up")
        PowerUpView(g, p, r.results)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(6.dp)); Text("Löschen") }
            Button(onClick = onClose) { Text("Schließen") }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Scan löschen?") },
        confirmButton = { TextButton(onClick = { Repo.deleteRecord(r.id); confirmDelete = false; onClose() }) { Text("Löschen", color = C.bad) } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Abbrechen") } },
    )
}
