package de.marlon.ivisor.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import de.marlon.ivisor.core.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class AppSettings(
    val trainerLevel: Int = 50,
    val nameTemplate: String = NameGen.DEFAULT_TEMPLATE,
    val autoSave: Boolean = true,
    val germanNames: Boolean = true,
    val pvpMaxLevel: Double = 50.0,
    val rankThreshold: Int = 100,
    val origin: Origin = Origin.WILD,
    val autoScanIntervalMs: Long = 1200,
    val arcCy: Float = -1f,      // relativ zur Bildhöhe
    val arcR: Float = -1f,       // relativ zur Bildbreite
    val arcSamples: Int = 0,
    val useArc: Boolean = true,
    val autoAppraisal: Boolean = true,
    val bubbleX: Int = 40,
    val bubbleY: Int = 400,
    val panelAlpha: Float = 0.96f,
) {
    val arcCalibrated get() = arcSamples > 0 && arcR > 0
    fun scanSettings() = ScanSettings(trainerLevel, origin, pvpMaxLevel)
}

object Repo {
    private lateinit var appCtx: Context
    private lateinit var prefs: SharedPreferences
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    var gameData by mutableStateOf<GameData?>(null); private set
    var loadError by mutableStateOf<String?>(null); private set
    var records by mutableStateOf<List<ScanRecord>>(emptyList()); private set
    var settings by mutableStateOf(AppSettings()); private set
    var overlayRunning by mutableStateOf(false)
    var autoScanActive by mutableStateOf(false)

    private val recordsFile get() = File(appCtx.filesDir, "scans.json")
    private val pvpokeFile get() = File(appCtx.filesDir, "pvpoke_gamemaster.json")
    private fun rankingFile(cap: Int) = File(appCtx.filesDir, "rankings_$cap.json")

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        prefs = appCtx.getSharedPreferences("ivisor", Context.MODE_PRIVATE)
        settings = loadSettings()
        scope.launch { loadGameData(); loadRecords() }
    }

    private suspend fun loadGameData() {
        try {
            var g = GameData.parse(appCtx.assets.open("gamedata.json").bufferedReader().use { it.readText() })
            if (pvpokeFile.exists()) runCatching { g = GameData.mergePvpoke(g, pvpokeFile.readText()) }
            for (cap in listOf(500, 1500, 2500, 10000)) {
                val f = rankingFile(cap)
                if (f.exists()) runCatching { g = GameData.withRankings(g, cap, f.readText()) }
            }
            val gd = g
            withContext(Dispatchers.Main) { gameData = gd }
            // Meta für Entwicklungsberater vorwärmen
            EvolutionAdvisor.ensureMeta(gd)
        } catch (e: Exception) {
            withContext(Dispatchers.Main) { loadError = e.message }
        }
    }

    /** Lädt aktuelle Daten von PvPoke (Basiswerte, Attacken, Ranglisten). */
    suspend fun updateFromInternet(): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val base = "https://raw.githubusercontent.com/pvpoke/pvpoke/master/src/data/"
            val gm = download(base + "gamemaster.min.json")
            val old = gameData ?: error("Daten noch nicht geladen")
            var g = GameData.mergePvpoke(old, gm)
            pvpokeFile.writeText(gm)
            for (cap in listOf(500, 1500, 2500, 10000)) {
                val r = runCatching { download(base + "rankings/all/overall/rankings-$cap.json") }.getOrNull() ?: continue
                g = GameData.withRankings(g, cap, r)
                rankingFile(cap).writeText(r)
            }
            withContext(Dispatchers.Main) { gameData = g }
            "${g.pokemon.size} Pokémon, ${g.moves.size} Attacken – Stand ${g.version}"
        }
    }

    private fun download(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        try {
            if (c.responseCode != 200) error("HTTP ${c.responseCode} für $url")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    fun resetData() {
        pvpokeFile.delete(); listOf(500, 1500, 2500, 10000).forEach { rankingFile(it).delete() }
        scope.launch { loadGameData() }
    }

    // ---------- Sammlung ----------
    private suspend fun loadRecords() {
        val list = runCatching {
            if (!recordsFile.exists()) emptyList()
            else (MiniJson.parse(recordsFile.readText()) as List<*>).mapNotNull { e ->
                @Suppress("UNCHECKED_CAST")
                runCatching { ScanRecord.fromJson(e as Map<String, Any?>) }.getOrNull()
            }
        }.getOrDefault(emptyList())
        withContext(Dispatchers.Main) { records = list }
    }

    private fun persist(list: List<ScanRecord>) {
        scope.launch(Dispatchers.IO) {
            synchronized(this@Repo) {
                val tmp = File(recordsFile.path + ".tmp")
                tmp.writeText(MiniJson.write(list.map { it.toJson() }))
                tmp.renameTo(recordsFile)
            }
        }
    }

    /**
     * Speichert einen Scan. Wird dasselbe Pokémon (Art, WP, KP) innerhalb von 30 Minuten erneut
     * gescannt, werden die IV-Kandidaten geschnitten statt ein Duplikat anzulegen.
     */
    @Synchronized
    fun saveScan(outcome: ScanOutcome): ScanRecord? {
        val p = outcome.species ?: return null
        val cp = outcome.parsed.cp ?: return null
        if (outcome.results.isEmpty()) return null
        val now = System.currentTimeMillis()
        val existing = records.firstOrNull { it.pokemonId == p.id && it.cp == cp && it.hp == outcome.parsed.hp && now - it.timestamp < 30 * 60_000 }
        val rec = if (existing != null) {
            val inter = IvCalculator.intersect(existing.results, outcome.results)
            existing.copy(results = inter.ifEmpty { outcome.results }, timestamp = now, lucky = existing.lucky || outcome.parsed.lucky)
        } else ScanRecord(now, p.id, cp, outcome.parsed.hp, outcome.parsed.dust, outcome.results, now, outcome.parsed.lucky)
        val list = if (existing != null) records.map { if (it.id == existing.id) rec else it } else listOf(rec) + records
        records = list; persist(list)
        return rec
    }

    fun updateRecord(r: ScanRecord) { val l = records.map { if (it.id == r.id) r else it }; records = l; persist(l) }
    fun deleteRecord(id: Long) { val l = records.filterNot { it.id == id }; records = l; persist(l) }
    fun deleteRecords(ids: Set<Long>) { val l = records.filterNot { it.id in ids }; records = l; persist(l) }
    fun clearRecords() { records = emptyList(); persist(emptyList()) }

    fun exportCsv(): File {
        val g = gameData
        val dir = File(appCtx.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, "ivisor_sammlung.csv")
        val sb = StringBuilder("Datum;Nr;Pokémon;WP;KP;Level;Angriff;Verteidigung;KP-IV;IV%;Variante;Kombinationen;SL-Rang;HL-Rang\n")
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.GERMANY)
        for (r in records) {
            val p = g?.byId?.get(r.pokemonId)
            val best = r.results.maxByOrNull { it.ivs.total }
            val gl = if (g != null && p != null && best != null) PvpCalculator.table(g, p, League.GREAT, settings.pvpMaxLevel).of(best.ivs)?.rank else null
            val ul = if (g != null && p != null && best != null) PvpCalculator.table(g, p, League.ULTRA, settings.pvpMaxLevel).of(best.ivs)?.rank else null
            sb.append(fmt.format(java.util.Date(r.timestamp))).append(';')
                .append(p?.dex ?: "").append(';').append(p?.nameDe ?: r.pokemonId).append(';')
                .append(r.cp).append(';').append(r.hp ?: "").append(';')
                .append(r.level?.let { formatLevel(it) } ?: r.results.map { it.level }.distinct().joinToString("/") { formatLevel(it) }).append(';')
                .append(if (r.exact) best?.ivs?.atk else "").append(';')
                .append(if (r.exact) best?.ivs?.def else "").append(';')
                .append(if (r.exact) best?.ivs?.sta else "").append(';')
                .append(r.pctLabel()).append(';').append(r.variant?.label ?: "?").append(';')
                .append(r.results.size).append(';').append(gl ?: "").append(';').append(ul ?: "").append('\n')
        }
        f.writeText(sb.toString())
        return f
    }

    // ---------- Einstellungen ----------
    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val s = transform(settings); settings = s
        prefs.edit()
            .putInt("trainerLevel", s.trainerLevel).putString("nameTemplate", s.nameTemplate)
            .putBoolean("autoSave", s.autoSave).putBoolean("germanNames", s.germanNames)
            .putFloat("pvpMaxLevel", s.pvpMaxLevel.toFloat()).putInt("rankThreshold", s.rankThreshold)
            .putString("origin", s.origin.name).putLong("autoScanIntervalMs", s.autoScanIntervalMs)
            .putFloat("arcCy", s.arcCy).putFloat("arcR", s.arcR).putInt("arcSamples", s.arcSamples)
            .putBoolean("useArc", s.useArc).putBoolean("autoAppraisal", s.autoAppraisal)
            .putInt("bubbleX", s.bubbleX).putInt("bubbleY", s.bubbleY).putFloat("panelAlpha", s.panelAlpha)
            .apply()
    }

    private fun loadSettings(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            trainerLevel = prefs.getInt("trainerLevel", d.trainerLevel),
            nameTemplate = prefs.getString("nameTemplate", d.nameTemplate) ?: d.nameTemplate,
            autoSave = prefs.getBoolean("autoSave", d.autoSave),
            germanNames = prefs.getBoolean("germanNames", d.germanNames),
            pvpMaxLevel = prefs.getFloat("pvpMaxLevel", d.pvpMaxLevel.toFloat()).toDouble(),
            rankThreshold = prefs.getInt("rankThreshold", d.rankThreshold),
            origin = runCatching { Origin.valueOf(prefs.getString("origin", d.origin.name)!!) }.getOrDefault(d.origin),
            autoScanIntervalMs = prefs.getLong("autoScanIntervalMs", d.autoScanIntervalMs),
            arcCy = prefs.getFloat("arcCy", d.arcCy), arcR = prefs.getFloat("arcR", d.arcR),
            arcSamples = prefs.getInt("arcSamples", d.arcSamples),
            useArc = prefs.getBoolean("useArc", d.useArc), autoAppraisal = prefs.getBoolean("autoAppraisal", d.autoAppraisal),
            bubbleX = prefs.getInt("bubbleX", d.bubbleX), bubbleY = prefs.getInt("bubbleY", d.bubbleY),
            panelAlpha = prefs.getFloat("panelAlpha", d.panelAlpha),
        )
    }

    /** Name für die Anzeige gemäß Spracheinstellung. */
    fun name(p: Pokemon?) = p?.display(settings.germanNames) ?: "?"
    fun moveName(m: Move?) = m?.display(settings.germanNames) ?: "?"
    fun typeName(i: Int) = gameData?.typeName(i, settings.germanNames) ?: ""

    fun nickname(r: ScanRecord): String? {
        val g = gameData ?: return null
        val p = g.byId[r.pokemonId] ?: return null
        val iv = r.results.minByOrNull { it.ivs.total } ?: return null
        return nicknameFor(g, p, iv)
    }

    fun nicknameFor(g: GameData, p: Pokemon, res: IvResult): String {
        val ranks = HashMap<League, Int>()
        val family = listOf(p) + g.evolutionsOf(p)
        for (l in League.entries) {
            val best = family.mapNotNull { t ->
                val table = PvpCalculator.table(g, t, l, settings.pvpMaxLevel)
                if (!table.relevant) null else table.of(res.ivs)?.takeIf { it.level >= res.level }?.rank
            }.minOrNull()
            if (best != null) ranks[l] = best
        }
        return NameGen.generate(settings.nameTemplate, NameGen.Ctx(res.ivs, res.level, p.nameDe, ranks, settings.rankThreshold))
    }
}
