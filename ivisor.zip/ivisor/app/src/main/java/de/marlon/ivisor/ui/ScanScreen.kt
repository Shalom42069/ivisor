package de.marlon.ivisor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import de.marlon.ivisor.core.Origin
import de.marlon.ivisor.data.Repo

@Composable
fun ScanScreen(onStart: () -> Unit, onStop: () -> Unit, onOpenCollection: () -> Unit) {
    val s = Repo.settings
    val running = Repo.overlayRunning
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Hero
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(C.accentBrush).padding(20.dp),
        ) {
            Text("IVisor", fontSize = 32.sp, fontWeight = FontWeight.Black)
            Text("IV-Scanner & PvP-/Raid-Rechner für Pokémon GO – alles frei, keine Paywall.", color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f))
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(if (running) C.good else C.bad))
                Spacer(Modifier.width(8.dp))
                Text(if (running) (if (Repo.autoScanActive) "Overlay aktiv · Auto-Scan läuft" else "Overlay aktiv") else "Overlay gestoppt", fontWeight = FontWeight.SemiBold)
            }
        }

        if (Repo.gameData == null) {
            Panel { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(20.dp)); Spacer(Modifier.width(12.dp)); Text(Repo.loadError ?: "Lade Spieldaten …") } }
        }

        if (!running) GradientButton("Overlay starten", Modifier.fillMaxWidth(), enabled = Repo.gameData != null, onClick = onStart)
        else OutlinedButton(onClick = onStop, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Overlay beenden") }

        Panel {
            SectionTitle("Trainer")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Trainerlevel", Modifier.weight(1f))
                IconButton(onClick = { Repo.updateSettings { it.copy(trainerLevel = (it.trainerLevel - 1).coerceAtLeast(1)) } }) { Text("−", fontSize = 22.sp) }
                Text("${s.trainerLevel}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                IconButton(onClick = { Repo.updateSettings { it.copy(trainerLevel = (it.trainerLevel + 1).coerceAtMost(80)) } }) { Text("+", fontSize = 22.sp) }
            }
            Text("Wird für den Level-Bogen und das Maximallevel genutzt.", color = C.textDim, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Text("Standard-Herkunft (Mindest-IV)", color = C.textDim, fontSize = 12.sp)
            ChipRow(Origin.entries, s.origin, { it.label }, { o -> Repo.updateSettings { it.copy(origin = o) } })
        }

        Panel {
            SectionTitle("So funktioniert's")
            Step("1", "Overlay starten und Bildschirmaufnahme erlauben (\"Gesamter Bildschirm\" oder nur Pokémon GO).")
            Step("2", "In Pokémon GO ein Pokémon öffnen und die schwebende Blase antippen.")
            Step("3", "Für exakte IVs: Bewertung öffnen, bis die Balken sichtbar sind, und erneut scannen.")
            Step("4", "Blase lange drücken = Auto-Scan: einfach durch die Pokémon wischen, alles landet automatisch in der Sammlung.")
            Step("5", "Namensvorschlag antippen → kopiert → im Spiel als Spitzname einfügen.")
        }

        Panel(onClick = onOpenCollection) {
            SectionTitle("Sammlung")
            val recs = Repo.records
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${recs.size} gescannte Pokémon", style = MaterialTheme.typography.titleMedium)
                    Text("${recs.count { it.minStars >= 3 }} mit ≥ 3★ · ${recs.count { it.minStars == 4 }} Hundos", color = C.textDim, fontSize = 13.sp)
                }
                Pill("Öffnen")
            }
        }

        Panel {
            SectionTitle("Level-Bogen")
            Text(
                if (s.arcCalibrated) "Kalibriert (${s.arcSamples} Messungen) – das Level wird zusätzlich über den Bogen bestimmt."
                else "Noch nicht kalibriert. Das passiert automatisch, sobald ein Scan ein eindeutiges Level ergibt.",
                color = C.textDim, fontSize = 13.sp,
            )
        }
        Text(
            "Hinweis: IVisor liest nur deinen Bildschirm (wie ein Screenshot) und greift nicht in das Spiel ein.",
            color = C.textDim, fontSize = 11.sp,
        )
    }
}

@Composable
private fun Step(n: String, text: String) {
    Row(Modifier.padding(vertical = 4.dp)) {
        Box(Modifier.size(22.dp).clip(RoundedCornerShape(50)).background(C.accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
            Text(n, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = C.accent)
        }
        Spacer(Modifier.width(10.dp))
        Text(text, fontSize = 14.sp)
    }
}
