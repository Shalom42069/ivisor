package de.marlon.ivisor.core

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class Ivs(val atk: Int, val def: Int, val sta: Int) {
    val total get() = atk + def + sta
    val percent get() = total * 100.0 / 45.0
    /** Sterne-Bewertung wie in der Spiel-Bewertung (0–4). */
    val stars get() = when {
        total == 45 -> 4
        total >= 37 -> 3
        total >= 30 -> 2
        total >= 23 -> 1
        else -> 0
    }
    override fun toString() = "$atk/$def/$sta"
}

object Stats {
    fun cp(p: Pokemon, iv: Ivs, cpm: Double): Int {
        val v = (p.atk + iv.atk) * sqrt((p.def + iv.def).toDouble()) * sqrt((p.sta + iv.sta).toDouble()) * cpm * cpm / 10.0
        return max(10, floor(v).toInt())
    }

    fun hp(p: Pokemon, sta: Int, cpm: Double): Int = max(10, floor((p.sta + sta) * cpm).toInt())

    fun cp(g: GameData, p: Pokemon, iv: Ivs, level: Double) = cp(p, iv, g.cpm(level))
    fun hp(g: GameData, p: Pokemon, iv: Ivs, level: Double) = hp(p, iv.sta, g.cpm(level))

    /** Stat-Produkt (Angriff × Verteidigung × KP) für PvP. */
    fun statProduct(p: Pokemon, iv: Ivs, cpm: Double): Double =
        (p.atk + iv.atk) * cpm * (p.def + iv.def) * cpm * floor((p.sta + iv.sta) * cpm)

    fun attack(p: Pokemon, iv: Int, cpm: Double, shadow: Boolean = false) = (p.atk + iv) * cpm * (if (shadow) 1.2 else 1.0)
    fun defense(p: Pokemon, iv: Int, cpm: Double, shadow: Boolean = false) = (p.def + iv) * cpm * (if (shadow) 5.0 / 6.0 else 1.0)
}

enum class Variant(val label: String, val dustMult: Double) {
    NORMAL("Normal", 1.0), SHADOW("Crypto", 1.2), PURIFIED("Erlöst", 0.9),
    LUCKY("Glücks", 0.5), LUCKY_PURIFIED("Glücks + Erlöst", 0.45);
}

/** Wie das Pokémon erhalten wurde → Mindest-IV. */
enum class Origin(val label: String, val floor: Int) {
    WILD("Wild / unbekannt", 0),
    WEATHER("Wetter-Boost", 4),
    RAID_EGG_RESEARCH("Raid / Ei / Feldforschung", 10),
    PURIFIED("Erlöst", 2),
    TRADE_GOOD("Tausch: Freund", 1),
    TRADE_GREAT("Tausch: Guter Freund", 2),
    TRADE_ULTRA("Tausch: Super-Freund", 3),
    TRADE_BEST("Tausch: Bester Freund", 5),
    LUCKY("Glückstausch", 12),
}

data class Appraisal(
    val atk: IntRange = 0..15,
    val def: IntRange = 0..15,
    val sta: IntRange = 0..15,
    val stars: Int? = null,
) {
    fun matches(iv: Ivs): Boolean =
        iv.atk in atk && iv.def in def && iv.sta in sta && (stars == null || iv.stars == stars)

    companion object {
        /** Balken-Bewertung: 0 = leer, 1..3 Segmente, 4 = rot/voll. */
        fun barRange(segments: Int): IntRange = when (segments) {
            0 -> 0..0
            1 -> 1..5
            2 -> 6..10
            3 -> 11..14
            4 -> 15..15
            else -> 0..15
        }
    }
}

data class IvResult(val level: Double, val ivs: Ivs, val variant: Variant, val cp: Int, val hp: Int)

data class ScanInput(
    val pokemon: Pokemon,
    val cp: Int,
    val hp: Int?,
    val dust: Int? = null,
    val levelHint: Double? = null,
    val levelHintTolerance: Double = 1.5,
    val variants: Set<Variant> = Variant.entries.toSet(),
    val ivFloor: Int = 0,
    val appraisal: Appraisal = Appraisal(),
    val maxLevel: Double? = null,
    val exactLevel: Double? = null,
)

object IvCalculator {
    fun candidateLevels(g: GameData, input: ScanInput): List<Pair<Double, Variant>> {
        val out = ArrayList<Pair<Double, Variant>>()
        val maxL = input.maxLevel ?: g.maxLevel
        for (lvl in g.levels) {
            if (lvl > maxL) continue
            if (input.exactLevel != null && lvl != input.exactLevel) continue
            if (input.levelHint != null && kotlin.math.abs(lvl - input.levelHint) > input.levelHintTolerance) continue
            for (v in input.variants) {
                if (input.dust != null) {
                    val base = g.dustCost(lvl) ?: continue
                    if ((base * v.dustMult).roundToInt() != input.dust) continue
                } else if (v != Variant.NORMAL && input.variants.size > 1) {
                    // Ohne Staubwert lässt sich die Variante nicht bestimmen – nur einmal rechnen.
                    continue
                }
                out.add(lvl to v)
            }
        }
        if (input.dust == null && out.isEmpty() && input.variants.isNotEmpty()) {
            val v = input.variants.first()
            for (lvl in g.levels) if (lvl <= maxL && (input.exactLevel == null || lvl == input.exactLevel)) out.add(lvl to v)
        }
        return out
    }

    fun calculate(g: GameData, input: ScanInput): List<IvResult> {
        val p = input.pokemon
        val res = ArrayList<IvResult>()
        val floorIv = input.ivFloor.coerceIn(0, 15)
        for ((lvl, variant) in candidateLevels(g, input)) {
            val cpm = g.cpm(lvl)
            for (s in floorIv..15) {
                val hp = Stats.hp(p, s, cpm)
                if (input.hp != null && hp != input.hp) continue
                if (s !in input.appraisal.sta) continue
                for (a in floorIv..15) {
                    if (a !in input.appraisal.atk) continue
                    for (d in floorIv..15) {
                        if (d !in input.appraisal.def) continue
                        val iv = Ivs(a, d, s)
                        if (input.appraisal.stars != null && iv.stars != input.appraisal.stars) continue
                        val cp = Stats.cp(p, iv, cpm)
                        if (cp == input.cp) res.add(IvResult(lvl, iv, variant, cp, hp))
                    }
                }
            }
        }
        return res
    }

    /** Schnittmenge mehrerer Scans desselben Pokémon (z. B. vor/nach Power-Up). */
    fun intersect(a: List<IvResult>, b: List<IvResult>): List<IvResult> {
        val set = b.map { it.ivs }.toSet()
        return a.filter { it.ivs in set }
    }
}

data class IvSummary(val minPct: Double, val maxPct: Double, val avgPct: Double, val levels: List<Double>, val count: Int) {
    val exact get() = count == 1
}

fun List<IvResult>.summary(): IvSummary? {
    if (isEmpty()) return null
    val p = map { it.ivs.percent }
    return IvSummary(p.min(), p.max(), p.average(), map { it.level }.distinct().sorted(), size)
}

fun formatLevel(l: Double): String = if (l % 1.0 == 0.0) l.toInt().toString() else l.toString()
