package de.marlon.ivisor.core

import kotlin.math.roundToInt

data class ScanSettings(
    val trainerLevel: Int = 50,
    val defaultOrigin: Origin = Origin.WILD,
    val pvpMaxLevel: Double = 50.0,
)

/** Ergebnis der Auswertung eines Bildschirms. */
data class ScanOutcome(
    val parsed: ParsedScreen,
    val species: Pokemon?,
    val alternatives: List<Pokemon>,
    val results: List<IvResult>,
    val nameConfidence: Double,
    val message: String? = null,
)

object ScanEngine {
    fun variantsFor(p: ParsedScreen): Set<Variant> = when {
        p.lucky && p.purifiedHint -> setOf(Variant.LUCKY_PURIFIED)
        p.lucky -> setOf(Variant.LUCKY, Variant.LUCKY_PURIFIED)
        else -> setOf(Variant.NORMAL, Variant.SHADOW, Variant.PURIFIED)
    }

    fun resolve(
        g: GameData, parsed: ParsedScreen, s: ScanSettings,
        forcedSpecies: Pokemon? = null, levelHint: Double? = null,
        ivFloor: Int = s.defaultOrigin.floor, appraisal: Appraisal = Appraisal(),
    ): ScanOutcome {
        val cp = parsed.cp; val hp = parsed.hp
        if (cp == null) return ScanOutcome(parsed, forcedSpecies, emptyList(), emptyList(), 0.0, "Keine WP erkannt – ist ein Pokémon-Detailbildschirm offen?")
        // Kandidaten-Arten sammeln: Name, Bonbon-Familie
        val cands = LinkedHashSet<Pokemon>()
        var conf = 0.0
        if (forcedSpecies != null) { cands.add(forcedSpecies); conf = 1.0 }
        else {
            parsed.name?.let { n ->
                val (list, score) = Fuzzy.bestSpecies(g, n)
                conf = score
                if (score >= 0.7) cands.addAll(list)
            }
            parsed.candyName?.let { c ->
                val (base, score) = Fuzzy.bestSpecies(g, c)
                if (score >= 0.7) base.forEach { b -> cands.addAll(g.family(b)) }
            }
        }
        val maxL = minOf(g.maxLevel, (s.trainerLevel + 10).toDouble())
        val scored = cands.map { p ->
            p to IvCalculator.calculate(g, ScanInput(p, cp, hp, parsed.dust, levelHint, 1.5, variantsFor(parsed), ivFloor, appraisal, maxL))
        }.let { list ->
            // Falls der Level-Hinweis alles ausschließt: ohne Hinweis erneut
            if (levelHint != null && list.all { it.second.isEmpty() })
                cands.map { p -> p to IvCalculator.calculate(g, ScanInput(p, cp, hp, parsed.dust, null, 1.5, variantsFor(parsed), ivFloor, appraisal, maxL)) }
            else list
        }
        val valid = scored.filter { it.second.isNotEmpty() }
        if (valid.isEmpty()) {
            val msg = if (cands.isEmpty()) "Art nicht erkannt – bitte auswählen." else "Keine IV-Kombination passt. Art/Variante prüfen oder erneut scannen."
            return ScanOutcome(parsed, cands.firstOrNull(), cands.toList(), emptyList(), conf, msg)
        }
        // Bevorzugt: exakter Namenstreffer mit Ergebnissen, sonst die Art mit den wenigsten Kombinationen
        val nameMatched = parsed.name?.let { n -> valid.filter { Fuzzy.similarity(n, it.first.nameDe.substringBefore(" (")) >= 0.8 || Fuzzy.similarity(n, it.first.name.substringBefore(" (")) >= 0.8 } } ?: emptyList()
        val pick = (nameMatched.ifEmpty { valid }).minBy { it.second.size }
        return ScanOutcome(parsed, pick.first, valid.map { it.first }, pick.second, conf)
    }
}

/** Gespeicherter Scan für die Sammlung. */
data class ScanRecord(
    val id: Long,
    val pokemonId: String,
    val cp: Int,
    val hp: Int?,
    val dust: Int?,
    val results: List<IvResult>,
    val timestamp: Long,
    val lucky: Boolean = false,
    val favorite: Boolean = false,
    val note: String = "",
) {
    val minPct get() = results.minOfOrNull { it.ivs.percent } ?: 0.0
    val maxPct get() = results.maxOfOrNull { it.ivs.percent } ?: 0.0
    val avgPct get() = if (results.isEmpty()) 0.0 else results.map { it.ivs.percent }.average()
    val minStars get() = results.minOfOrNull { it.ivs.stars } ?: 0
    val maxStars get() = results.maxOfOrNull { it.ivs.stars } ?: 0
    val exact get() = results.map { it.ivs }.distinct().size == 1
    val level: Double? get() = results.map { it.level }.distinct().singleOrNull()
    val variant: Variant? get() = results.map { it.variant }.distinct().singleOrNull()
    fun pctLabel(): String = if (results.isEmpty()) "?" else if (minPct.roundToInt() == maxPct.roundToInt()) "${maxPct.roundToInt()}%" else "${minPct.roundToInt()}–${maxPct.roundToInt()}%"

    fun toJson(): Map<String, Any?> = mapOf(
        "id" to id, "p" to pokemonId, "cp" to cp, "hp" to hp, "dust" to dust, "ts" to timestamp,
        "lucky" to lucky, "fav" to favorite, "note" to note,
        "r" to results.map { listOf(it.level, it.ivs.atk, it.ivs.def, it.ivs.sta, it.variant.name, it.cp, it.hp) },
    )

    companion object {
        fun fromJson(m: Map<String, Any?>): ScanRecord = ScanRecord(
            id = (m["id"] as Number).toLong(), pokemonId = m["p"] as String, cp = m["cp"].int(),
            hp = (m["hp"] as? Number)?.toInt(), dust = (m["dust"] as? Number)?.toInt(),
            results = (m["r"] as List<*>).map { r ->
                val l = r as List<*>
                IvResult((l[0] as Number).toDouble(), Ivs(l[1].int(), l[2].int(), l[3].int()),
                    runCatching { Variant.valueOf(l[4] as String) }.getOrDefault(Variant.NORMAL), l[5].int(), l[6].int())
            },
            timestamp = (m["ts"] as Number).toLong(), lucky = m["lucky"] == true, favorite = m["fav"] == true,
            note = m["note"] as? String ?: "",
        )
    }
}
