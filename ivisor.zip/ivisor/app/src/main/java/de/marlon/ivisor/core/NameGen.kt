package de.marlon.ivisor.core

import kotlin.math.roundToInt

/**
 * Erzeugt Spitznamen (max. 12 Zeichen in Pokémon GO) aus Scan-Ergebnissen.
 *
 * Platzhalter:
 *  {IV}   IV in %, gerundet (z. B. 96)      {IV%}  mit Prozentzeichen
 *  {A} {D} {S}   Einzelwerte hex (0–F)       {ADS}  alle drei hex
 *  {Ac}{Dc}{Sc}  eingekreiste Zahlen ⓪–⑮     {ADSc} alle drei eingekreist
 *  {Ab} {Db} {Sb} fette Ziffern 𝟏𝟓 (Unicode)
 *  {LV}   Level     {★} Sterne (0–4 als ★)
 *  {SL} {HL} {LC} {ML} PvP-Rang der jeweiligen Liga (beste Entwicklung) – leer, wenn > Schwelle
 *  {NAME} Name (gekürzt)
 */
object NameGen {
    const val DEFAULT_TEMPLATE = "{IV}{ADSc}"
    const val MAX_LEN = 12

    private val circled = listOf("⓪", "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨", "⑩", "⑪", "⑫", "⑬", "⑭", "⑮")
    private val bold = listOf("𝟎", "𝟏", "𝟐", "𝟑", "𝟒", "𝟓", "𝟔", "𝟕", "𝟖", "𝟗")

    fun hex(v: Int) = "0123456789ABCDEF"[v].toString()
    fun boldNum(v: Int) = v.toString().map { bold[it - '0'] }.joinToString("")

    data class Ctx(
        val ivs: Ivs,
        val level: Double?,
        val name: String,
        val ranks: Map<League, Int> = emptyMap(),
        val rankThreshold: Int = 100,
    )

    fun generate(template: String, c: Ctx): String {
        var s = template
        fun rep(k: String, v: String) { s = s.replace(k, v) }
        rep("{IV%}", "${c.ivs.percent.roundToInt()}%")
        rep("{IV}", c.ivs.percent.roundToInt().toString())
        rep("{ADSc}", circled[c.ivs.atk] + circled[c.ivs.def] + circled[c.ivs.sta])
        rep("{ADS}", hex(c.ivs.atk) + hex(c.ivs.def) + hex(c.ivs.sta))
        rep("{Ac}", circled[c.ivs.atk]); rep("{Dc}", circled[c.ivs.def]); rep("{Sc}", circled[c.ivs.sta])
        rep("{Ab}", boldNum(c.ivs.atk)); rep("{Db}", boldNum(c.ivs.def)); rep("{Sb}", boldNum(c.ivs.sta))
        rep("{A}", hex(c.ivs.atk)); rep("{D}", hex(c.ivs.def)); rep("{S}", hex(c.ivs.sta))
        rep("{LV}", c.level?.let { formatLevel(it) } ?: "")
        rep("{★}", "★".repeat(c.ivs.stars))
        for (l in League.entries) {
            val r = c.ranks[l]
            rep("{${l.short}}", if (r != null && r <= c.rankThreshold) "${l.short.first()}$r" else "")
        }
        rep("{NAME}", c.name)
        return truncate(s.trim())
    }

    /** Kürzt auf 12 sichtbare Zeichen (Unicode-Codepoints). */
    fun truncate(s: String): String {
        val cps = s.codePoints().toArray()
        return if (cps.size <= MAX_LEN) s else String(cps, 0, MAX_LEN)
    }
}
