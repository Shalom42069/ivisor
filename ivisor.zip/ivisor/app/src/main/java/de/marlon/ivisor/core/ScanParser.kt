package de.marlon.ivisor.core

import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Eine erkannte Textzeile mit Bounding-Box in Pixeln. */
data class OcrLine(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val cy get() = (top + bottom) / 2
    val cx get() = (left + right) / 2
    val height get() = bottom - top
}

data class ParsedScreen(
    val cp: Int? = null,
    val hp: Int? = null,
    val hpCurrent: Int? = null,
    val dust: Int? = null,
    val candyName: String? = null,
    val name: String? = null,
    val lucky: Boolean = false,
    val shadowHint: Boolean = false,
    val purifiedHint: Boolean = false,
    val isPokemonScreen: Boolean = false,
    val appraisalVisible: Boolean = false,
)

object ScanParser {
    private val cpRegex = Regex("""(?:CP|WP|PC|PS|C P|W P)\s*[:.]?\s*([0-9OoIlSB ]{2,6})""", RegexOption.IGNORE_CASE)
    private val hpRegex = Regex("""([0-9OoIlSB]{1,4})\s*/\s*([0-9OoIlSB]{1,4})\s*(HP|KP|PV|PS|PC)""", RegexOption.IGNORE_CASE)
    private val hpRegex2 = Regex("""(HP|KP|PV|PS)\s*([0-9OoIlSB]{1,4})\s*/\s*([0-9OoIlSB]{1,4})""", RegexOption.IGNORE_CASE)
    private val candyRegex = Regex("""^(.+?)[\s-]*(BONBON|BONBONS|CANDY|BONBÓN|CARAMELLE|CARAMELO|BONBONS?)\b""", RegexOption.IGNORE_CASE)
    private val numRegex = Regex("""[0-9][0-9.,\s]*[0-9]|[0-9]""")

    fun fixDigits(s: String): String = s.map {
        when (it) { 'O', 'o', 'D' -> '0'; 'I', 'l', '|', 'i' -> '1'; 'S', 's' -> '5'; 'B' -> '8'; 'Z' -> '2'; else -> it }
    }.filter { it.isDigit() }.joinToString("")

    /**
     * @param validDust alle möglichen Staubkosten (inkl. Multiplikatoren) zur Plausibilisierung.
     */
    fun parse(lines: List<OcrLine>, width: Int, height: Int, validDust: Set<Int>): ParsedScreen {
        var cp: Int? = null; var hp: Int? = null; var hpCur: Int? = null
        var candy: String? = null; var lucky = false; var appraisal = false
        var shadowHint = false; var purifiedHint = false

        // WP: oberes Drittel, größte passende Zeile
        for (l in lines.filter { it.cy < height * 0.4 }.sortedBy { it.top }) {
            val m = cpRegex.find(l.text) ?: continue
            val v = fixDigits(m.groupValues[1]).toIntOrNull() ?: continue
            if (v in 10..10000) { cp = v; break }
        }
        if (cp == null) {
            // Fallback: "WP" und Zahl als getrennte Zeilen → größte reine Zahl im oberen Bereich nahe der Mitte
            val hasCpLabel = lines.any { it.cy < height * 0.3 && it.text.trim().uppercase() in setOf("CP", "WP", "PC", "PS") }
            if (hasCpLabel) {
                cp = lines.filter { it.cy < height * 0.3 && abs(it.cx - width / 2) < width * 0.3 }
                    .mapNotNull { l -> fixDigits(l.text).takeIf { d -> d.length in 2..5 && l.text.count { it.isLetter() } <= 1 }?.toIntOrNull()?.let { it to l.height } }
                    .filter { it.first in 10..10000 }.maxByOrNull { it.second }?.first
            }
        }
        for (l in lines) {
            val t = l.text
            hpRegex.find(t)?.let { m ->
                val a = fixDigits(m.groupValues[1]).toIntOrNull(); val b = fixDigits(m.groupValues[2]).toIntOrNull()
                if (b != null && b in 10..1000) { hp = b; hpCur = a }
            } ?: hpRegex2.find(t)?.let { m ->
                val a = fixDigits(m.groupValues[2]).toIntOrNull(); val b = fixDigits(m.groupValues[3]).toIntOrNull()
                if (b != null && b in 10..1000) { hp = b; hpCur = a }
            }
            val up = t.uppercase()
            if (candy == null) candyRegex.find(t.trim())?.let { m ->
                val n = m.groupValues[1].trim().trimEnd('-')
                if (n.length >= 3 && !n.any { it.isDigit() }) candy = n
            }
            if ("GLÜCKS" in up || "GLUCKS" in up || "LUCKY" in up) lucky = true
            if ("CRYPTO" in up || "SHADOW" in up || "ERLÖSEN" in up || "PURIFY" in up) shadowHint = true
            if ("ERLÖST" in up || "PURIFIED" in up) purifiedHint = true
            if ("BEWERT" in up || "APPRAIS" in up || "ANGRIFF" in up && "VERTEIDIGUNG" in up) appraisal = true
        }

        // Staubkosten: unterste Zahl auf dem Bildschirm, die ein gültiger Kostenwert ist
        var dust: Int? = null; var dustY = -1
        for (l in lines.filter { it.cy > height * 0.55 }) {
            for (m in numRegex.findAll(l.text)) {
                val raw = m.value.replace(".", "").replace(",", "").replace(" ", "")
                val v = raw.toIntOrNull() ?: continue
                if (v in validDust && l.cy > dustY) { dust = v; dustY = l.cy }
            }
        }

        // Name: Zeile im mittleren Bereich, rein alphabetisch, möglichst groß
        val name = lines.asSequence()
            .filter { it.cy in (height * 0.25).toInt()..(height * 0.6).toInt() }
            .filter { l -> val t = l.text.trim(); t.length in 2..24 && t.count { it.isLetter() } >= max(2, t.length - 3) && !t.contains("/") }
            .filter { l -> val u = l.text.uppercase(); listOf("KP", "HP", "GEWICHT", "WEIGHT", "GRÖSSE", "HEIGHT", "BONBON", "CANDY", "STERNENSTAUB", "STARDUST", "POWER", "ENTWICKELN", "EVOLVE", "KG", "M").none { u == it || u.startsWith("$it ") || u.contains("BONBON") || u.contains("CANDY") } }
            .sortedWith(compareByDescending<OcrLine> { it.height }.thenBy { abs(it.cx - width / 2) })
            .firstOrNull()?.text?.trim()

        return ParsedScreen(
            cp = cp, hp = hp, hpCurrent = hpCur, dust = dust, candyName = candy, name = name, lucky = lucky,
            shadowHint = shadowHint, purifiedHint = purifiedHint,
            isPokemonScreen = cp != null && hp != null, appraisalVisible = appraisal,
        )
    }

    fun validDustValues(g: GameData): Set<Int> {
        val out = HashSet<Int>()
        for (l in g.levels) { val d = g.dustCost(l) ?: continue; for (v in Variant.entries) out.add(Math.round(d * v.dustMult).toInt()) }
        return out
    }
}

object Fuzzy {
    fun normalize(s: String): String {
        val n = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
        return n.replace(Regex("\\p{M}+"), "").replace("ß", "ss").filter { it.isLetterOrDigit() }
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    fun similarity(a: String, b: String): Double {
        val x = normalize(a); val y = normalize(b)
        if (x.isEmpty() || y.isEmpty()) return 0.0
        return 1.0 - levenshtein(x, y).toDouble() / max(x.length, y.length)
    }

    /** Beste Art zu einem gelesenen Namen (Basisname ohne Form). */
    fun bestSpecies(g: GameData, text: String): Pair<List<Pokemon>, Double> {
        var bestScore = 0.0; var bestDex = -1
        for (p in g.pokemon) {
            if (p.isMega) continue
            val names = listOf(p.nameDe.substringBefore(" ("), p.name.substringBefore(" ("))
            for (n in names) {
                val s = similarity(text, n)
                if (s > bestScore) { bestScore = s; bestDex = p.dex }
            }
        }
        val list = if (bestDex < 0) emptyList() else g.pokemon.filter { it.dex == bestDex && !it.isMega }
        return list to bestScore
    }
}
