package de.marlon.ivisor.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Geometrie des Level-Bogens auf dem Pokémon-Detailbildschirm.
 * Der Bogen ist ein Halbkreis mit Mittelpunkt (w/2, cy) und Radius r.
 * Position des Punkts ~ linear im CP-Multiplikator zwischen Level 1 und (Trainerlevel + 2, max 50).
 */
object ArcMath {
    fun arcMaxLevel(trainerLevel: Int): Double = minOf(trainerLevel + 2, 50).toDouble()

    fun fraction(g: GameData, level: Double, trainerLevel: Int): Double {
        val maxL = arcMaxLevel(trainerLevel)
        val l = minOf(level, maxL)
        return (g.cpm(l) - g.cpm(1.0)) / (g.cpm(maxL) - g.cpm(1.0))
    }

    /** Aus einem Punkt mit bekanntem Level Mittelpunkt-y und Radius ableiten. Null, wenn zu ungenau. */
    fun calibrate(dotX: Float, dotY: Float, width: Int, height: Int, f: Double): Pair<Float, Float>? {
        val cx = width / 2f
        val c = cos(PI * f)
        if (abs(c) < 0.3) return null
        val r = ((cx - dotX) / c).toFloat()
        if (r < width * 0.25f || r > width * 0.55f) return null
        val cy = (dotY + r * sin(PI * f)).toFloat()
        if (cy < height * 0.1f || cy > height * 0.6f) return null
        return (cy / height) to (r / width)
    }

    /** Punkt → Bogenanteil 0..1 */
    fun fractionFromDot(dotX: Float, dotY: Float, width: Int, height: Int, cyRel: Float): Double {
        val cx = width / 2f; val cy = cyRel * height
        val angle = atan2((cy - dotY).toDouble(), (dotX - cx).toDouble()) // 0 = rechts, PI = links
        return (1.0 - angle / PI).coerceIn(0.0, 1.0)
    }

    fun levelFromFraction(g: GameData, f: Double, trainerLevel: Int): Double {
        val maxL = arcMaxLevel(trainerLevel)
        return g.levels.filter { it <= maxL }.minBy { abs(fraction(g, it, trainerLevel) - f) }
    }

    /** Liegt ein Punkt plausibel auf dem kalibrierten Bogen? */
    fun onArc(dotX: Float, dotY: Float, width: Int, height: Int, cyRel: Float, rRel: Float, tol: Float = 0.035f): Boolean {
        val dx = dotX - width / 2f; val dy = dotY - cyRel * height
        val d = kotlin.math.sqrt(dx * dx + dy * dy)
        return abs(d - rRel * width) < tol * width && dotY <= cyRel * height + width * 0.02f
    }
}
