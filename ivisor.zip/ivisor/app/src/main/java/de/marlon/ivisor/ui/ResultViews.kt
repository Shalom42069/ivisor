package de.marlon.ivisor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import de.marlon.ivisor.core.*
import de.marlon.ivisor.data.Repo
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.roundToInt

private val nf = NumberFormat.getIntegerInstance(Locale.GERMANY)
fun fmt(n: Int) = nf.format(n)

/** Kopfzeile: Badge, Name, Typen, Sterne, Level. */
@Composable
fun ResultHeader(g: GameData, p: Pokemon, results: List<IvResult>, cp: Int?, hp: Int?, trailing: @Composable () -> Unit = {}) {
    val sum = results.summary()
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (sum != null) IvBadge(sum.minPct, sum.maxPct, 58.dp) else IvBadge(0.0, 0.0, 58.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Repo.name(p), style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                Spacer(Modifier.width(6.dp))
                p.types.forEach { TypeChip(g, it); Spacer(Modifier.width(3.dp)) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (cp != null) Text("WP $cp", color = C.textDim, fontSize = 13.sp)
                if (hp != null) Text("  ·  KP $hp", color = C.textDim, fontSize = 13.sp)
                if (sum != null) {
                    Text("  ·  Lv " + sum.levels.let { l -> if (l.size == 1) formatLevel(l[0]) else "${formatLevel(l.first())}–${formatLevel(l.last())}" }, color = C.textDim, fontSize = 13.sp)
                }
            }
            if (sum != null) Row(verticalAlignment = Alignment.CenterVertically) {
                Stars(results.minOf { it.ivs.stars })
                Spacer(Modifier.width(8.dp))
                Text(if (sum.exact) "exakt" else "${sum.count} Möglichkeiten", color = C.textDim, fontSize = 12.sp)
                results.map { it.variant }.distinct().singleOrNull()?.takeIf { it != Variant.NORMAL }?.let {
                    Spacer(Modifier.width(8.dp)); Pill(it.label, if (it == Variant.SHADOW) C.accent else C.good)
                }
            }
        }
        trailing()
    }
}

/** Min/Max je Einzelwert als Balken. */
@Composable
fun IvBars(results: List<IvResult>) {
    if (results.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        StatBar("ANG", results.minOf { it.ivs.atk }..results.maxOf { it.ivs.atk })
        StatBar("VER", results.minOf { it.ivs.def }..results.maxOf { it.ivs.def })
        StatBar("KP", results.minOf { it.ivs.sta }..results.maxOf { it.ivs.sta })
    }
}

@Composable
fun ComboList(results: List<IvResult>, max: Int = 12) {
    val sorted = results.sortedByDescending { it.ivs.total }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
            listOf("Lv", "ANG", "VER", "KP", "IV").forEach { Text(it, Modifier.weight(1f), color = C.textDim, fontSize = 11.sp) }
        }
        sorted.take(max).forEach { r ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(C.surface2).padding(horizontal = 4.dp, vertical = 4.dp)) {
                Text(formatLevel(r.level), Modifier.weight(1f), fontSize = 13.sp)
                Text("${r.ivs.atk}", Modifier.weight(1f), fontSize = 13.sp)
                Text("${r.ivs.def}", Modifier.weight(1f), fontSize = 13.sp)
                Text("${r.ivs.sta}", Modifier.weight(1f), fontSize = 13.sp)
                Text("${r.ivs.percent.roundToInt()}%", Modifier.weight(1f), fontSize = 13.sp, color = C.iv(r.ivs.percent), fontWeight = FontWeight.Bold)
            }
        }
        if (sorted.size > max) Text("… und ${sorted.size - max} weitere", color = C.textDim, fontSize = 12.sp)
    }
}

data class LeagueCell(val minRank: Int, val maxRank: Int, val level: Double, val cp: Int, val pct: Double, val tooHigh: Boolean)

fun leagueCell(g: GameData, target: Pokemon, league: League, results: List<IvResult>, maxLevel: Double): LeagueCell? {
    val t = PvpCalculator.table(g, target, league, maxLevel)
    if (!t.relevant) return null
    val entries = results.mapNotNull { r -> t.of(r.ivs)?.let { it to r } }
    if (entries.isEmpty()) return null
    val best = entries.minBy { it.first.rank }
    return LeagueCell(
        entries.minOf { it.first.rank }, entries.maxOf { it.first.rank }, best.first.level, best.first.cp,
        best.first.percentOfBest, entries.all { (e, r) -> r.level > e.level && league != League.MASTER },
    )
}

/** PvP-Tabelle für Art + alle Weiterentwicklungen. */
@Composable
fun PvpTableView(g: GameData, p: Pokemon, results: List<IvResult>, maxLevel: Double) {
    if (results.isEmpty()) return
    val targets = remember(p.id) { listOf(p) + g.evolutionsOf(p) }
    val leagues = listOf(League.LITTLE, League.GREAT, League.ULTRA, League.MASTER)
    val cells = remember(p.id, results, maxLevel, g) {
        targets.map { t -> t to leagues.map { l -> leagueCell(g, t, l, results, maxLevel) } }
    }
    val shownLeagues = leagues.filterIndexed { i, _ -> cells.any { it.second[i] != null } }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text("", Modifier.weight(1.4f))
            shownLeagues.forEach { Text(it.short, Modifier.weight(1f), color = C.textDim, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        }
        cells.forEach { (t, row) ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(C.surface2).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(Repo.name(t), Modifier.weight(1.4f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                leagues.forEachIndexed { i, l ->
                    if (l in shownLeagues) {
                        val c = row[i]
                        Column(Modifier.weight(1f)) {
                            if (c == null) Text("–", color = C.textDim, fontSize = 13.sp)
                            else {
                                val rankTxt = if (c.minRank == c.maxRank) "#${c.minRank}" else "#${c.minRank}-${c.maxRank}"
                                Text(rankTxt, color = if (c.tooHigh) C.textDim else C.rank(c.minRank), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(if (c.tooHigh) "zu hoch" else "${c.cp} · L${formatLevel(c.level)}", color = C.textDim, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PowerUpView(g: GameData, p: Pokemon, results: List<IvResult>) {
    val r = results.singleOrNull() ?: results.minByOrNull { it.level } ?: return
    val variant = results.map { it.variant }.distinct().singleOrNull() ?: Variant.NORMAL
    val targets = buildList {
        for (l in listOf(League.GREAT, League.ULTRA)) {
            val lv = PowerUp.maxLevelUnder(g, p, r.ivs, l.cap, 50.0)
            if (lv != null && lv > r.level) add("${l.short} (L${formatLevel(lv)})" to lv)
        }
        if (r.level < 40.0) add("Level 40" to 40.0)
        if (r.level < 50.0) add("Level 50" to 50.0)
    }
    if (targets.isEmpty()) { Text("Bereits auf Maximallevel.", color = C.textDim); return }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        targets.forEach { (label, lv) ->
            val c = PowerUp.cost(g, r.level, lv, variant)
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(C.surface2).padding(8.dp)) {
                Text(label, Modifier.weight(1.2f), fontSize = 13.sp)
                Text("${fmt(c.stardust)} ✦", Modifier.weight(1.2f), fontSize = 13.sp, color = C.gold)
                Text("${c.candy} 🍬" + if (c.xlCandy > 0) " ${c.xlCandy} XL" else "", Modifier.weight(1.2f), fontSize = 13.sp)
                Text("WP ${Stats.cp(g, p, r.ivs, lv)}", Modifier.weight(1f), fontSize = 13.sp, color = C.textDim)
            }
        }
    }
}

@Composable
fun NicknameRow(name: String, onCopy: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.surface2).clickable(onClick = onCopy).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text("Namensvorschlag", color = C.textDim, fontSize = 11.sp)
            Text(name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Pill("Kopieren", C.accent)
    }
}
