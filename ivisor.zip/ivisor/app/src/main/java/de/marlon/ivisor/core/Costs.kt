package de.marlon.ivisor.core

import kotlin.math.ceil

data class PowerUpCost(val stardust: Int, val candy: Int, val xlCandy: Int, val steps: Int)

object PowerUp {
    /** Kosten, um von [from] auf [to] zu leveln (Halbstufen). Best-Buddy-Level 51 ist nicht aufbaubar. */
    fun cost(g: GameData, from: Double, to: Double, variant: Variant = Variant.NORMAL): PowerUpCost {
        var dust = 0; var candy = 0; var xl = 0; var steps = 0
        var l = from
        val candyMult = when (variant) {
            Variant.SHADOW -> g.shadowCandyMult
            Variant.PURIFIED, Variant.LUCKY_PURIFIED -> g.purifiedCandyMult
            else -> 1.0
        }
        val dustMult = variant.dustMult
        while (l < to && l < g.maxPowerUpLevel) {
            val d = g.dustCost(l) ?: break
            val (c, x) = g.candyCost(l) ?: break
            dust += Math.round(d * dustMult).toInt()
            candy += if (c == 0) 0 else ceil(c * candyMult - 1e-9).toInt()
            xl += if (x == 0) 0 else ceil(x * candyMult - 1e-9).toInt()
            steps++
            l += 0.5
        }
        return PowerUpCost(dust, candy, xl, steps)
    }

    /** Höchstes Level unter einem CP-Limit. */
    fun maxLevelUnder(g: GameData, p: Pokemon, iv: Ivs, cap: Int, maxLevel: Double = 50.0): Double? =
        g.levels.filter { it <= maxLevel }.lastOrNull { Stats.cp(g, p, iv, it) <= cap }
}
