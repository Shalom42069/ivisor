package de.marlon.ivisor.core

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.pow

enum class RaidTier(val label: String, val cpm: Double, val hp: Int) {
    T1("Stufe 1", 0.5974, 600),
    T3("Stufe 3", 0.73, 3600),
    T5("Stufe 5 / Legendär", 0.79, 15000),
    MEGA("Mega", 0.79, 9000),
    MEGA_LEGENDARY("Mega-Legendär / Proto", 0.79, 22500),
    ELITE("Elite", 0.79, 20000),
    SHADOW_T5("Crypto-Legendär", 0.79, 22500);
}

enum class Weather(val label: String, val boosted: List<String>) {
    NONE("Kein Boost", emptyList()),
    SUNNY("Sonnig/Klar", listOf("grass", "ground", "fire")),
    RAIN("Regen", listOf("water", "electric", "bug")),
    PARTLY("Teilweise bewölkt", listOf("normal", "rock")),
    CLOUDY("Bewölkt", listOf("fairy", "fighting", "poison")),
    WINDY("Windig", listOf("dragon", "flying", "psychic")),
    SNOW("Schnee", listOf("ice", "steel")),
    FOG("Nebel", listOf("dark", "ghost"));
}

data class Counter(
    val pokemon: Pokemon,
    val fast: Move,
    val charged: Move,
    val shadow: Boolean,
    val dps: Double,
    val tdo: Double,
    val score: Double,
    val eliteMove: Boolean,
)

data class RaidOptions(
    val tier: RaidTier = RaidTier.T5,
    val attackerLevel: Double = 40.0,
    val attackerIv: Int = 15,
    val weather: Weather = Weather.NONE,
    val includeShadow: Boolean = true,
    val includeMega: Boolean = true,
    val includeLegendary: Boolean = true,
    val includeElite: Boolean = true,
    val friendBonus: Double = 1.0,
)

object RaidCalculator {
    /** Standard-Schadensformel aus Pokémon GO. */
    fun damage(power: Double, atk: Double, def: Double, mult: Double): Int =
        floor(0.5 * power * (atk / def) * mult).toInt() + 1

    fun counters(g: GameData, boss: Pokemon, o: RaidOptions, limit: Int = 60): List<Counter> {
        val bossDef = (boss.def + 15) * o.tier.cpm
        val bossAtk = (boss.atk + 15) * o.tier.cpm
        val cpm = g.cpm(o.attackerLevel)
        val boosted = o.weather.boosted.map { g.typeIndex(it) }.toSet()
        // Durchschnittlicher eingehender Schaden: Mittel über Boss-Attacken (grobe Näherung à la GamePress)
        val bossMoves = (boss.fast + boss.charged).mapNotNull { g.moves[it] }
        val out = ArrayList<Counter>()
        for (p in g.pokemon) {
            if (p.isMega && !o.includeMega) continue
            if (p.isLegendary && !o.includeLegendary) continue
            val shadowOptions = if (o.includeShadow && p.flags and Flags.SHADOW_ELIGIBLE != 0 && !p.isMega) listOf(false, true) else listOf(false)
            for (sh in shadowOptions) {
                var best: Counter? = null
                val atk = Stats.attack(p, o.attackerIv, cpm, sh)
                val def = Stats.defense(p, o.attackerIv, cpm, sh)
                val hp = Stats.hp(p, o.attackerIv, cpm).toDouble()
                // eingehender DPS-Schätzer, abhängig von Typ-Matchup der Boss-Attacken
                val incoming = if (bossMoves.isEmpty()) 900.0 / def else {
                    val avgEff = bossMoves.map { m ->
                        val stab = if (m.type in boss.types) 1.2 else 1.0
                        m.pvePower * stab * g.effectiveness(m.type, p.types) / (m.pveDurationMs / 1000.0).coerceAtLeast(0.5)
                    }.average()
                    max(0.5, 0.5 * avgEff * bossAtk / def * 0.6)
                }
                for (fId in p.fast) {
                    val f = g.moves[fId] ?: continue
                    val fElite = fId in p.elite
                    if (fElite && !o.includeElite) continue
                    for (cId in p.charged) {
                        val c = g.moves[cId] ?: continue
                        val cElite = cId in p.elite
                        if (cElite && !o.includeElite) continue
                        val dps = cycleDps(g, p, f, c, atk, bossDef, boss, boosted, o.friendBonus)
                        val survive = hp / incoming
                        val tdo = dps * survive
                        val score = (dps.pow(3) * tdo).pow(0.25)
                        if (best == null || score > best.score) best = Counter(p, f, c, sh, dps, tdo, score, fElite || cElite)
                    }
                }
                best?.let { out.add(it) }
            }
        }
        return out.sortedByDescending { it.score }.take(limit)
    }

    fun cycleDps(
        g: GameData, p: Pokemon, f: Move, c: Move, atk: Double, bossDef: Double, boss: Pokemon,
        boosted: Set<Int>, friend: Double,
    ): Double {
        fun mult(m: Move): Double {
            val stab = if (m.type in p.types) 1.2 else 1.0
            val wb = if (m.type in boosted) 1.2 else 1.0
            return stab * wb * friend * g.effectiveness(m.type, boss.types)
        }
        val fDmg = damage(f.pvePower, atk, bossDef, mult(f)).toDouble()
        val cDmg = damage(c.pvePower, atk, bossDef, mult(c)).toDouble()
        val fDur = f.pveDurationMs / 1000.0
        val cDur = c.pveDurationMs / 1000.0
        val fE = f.pveEnergy.toDouble().coerceAtLeast(1.0)
        val cE = c.pveEnergy.toDouble().coerceAtLeast(1.0)
        // Zyklus: n Sofortattacken + 1 Ladeattacke
        val n = cE / fE
        return (n * fDmg + cDmg) / (n * fDur + cDur)
    }

    /** Fangbare WP-Spanne nach dem Raid (Lvl 20 / 25 mit Wetter, IV ≥ 10). */
    fun catchCp(g: GameData, boss: Pokemon): Pair<IntRange, IntRange> {
        fun range(l: Double) = Stats.cp(g, boss, Ivs(10, 10, 10), l)..Stats.cp(g, boss, Ivs(15, 15, 15), l)
        return range(20.0) to range(25.0)
    }

    fun bossCp(boss: Pokemon, tier: RaidTier): Int =
        floor((boss.atk + 15) * Math.sqrt((boss.def + 15).toDouble()) * Math.sqrt(tier.hp.toDouble()) / 10.0).toInt()
}
