package de.marlon.ivisor.core

import kotlin.math.ceil

enum class League(val label: String, val short: String, val cap: Int) {
    LITTLE("Little Cup", "LC", 500),
    GREAT("Superliga", "SL", 1500),
    ULTRA("Hyperliga", "HL", 2500),
    MASTER("Meisterliga", "ML", Int.MAX_VALUE);
}

data class PvpEntry(
    val ivs: Ivs,
    val level: Double,
    val cp: Int,
    val statProduct: Double,
    val atk: Double,
    val def: Double,
    val hp: Int,
    val rank: Int,
    val percentOfBest: Double,
)

class PvpTable(val pokemon: Pokemon, val league: League, val maxLevel: Double, val ivFloor: Int, val entries: List<PvpEntry>) {
    private val byIv = entries.associateBy { it.ivs }
    fun of(iv: Ivs): PvpEntry? = byIv[iv]
    val best get() = entries.first()
    /** Liga sinnvoll? (Rang-1 erreicht mind. 90 % des WP-Limits) */
    val relevant get() = league == League.MASTER || best.cp >= league.cap * 0.9
}

object PvpCalculator {
    private val cache = HashMap<String, PvpTable>()

    fun table(g: GameData, p: Pokemon, league: League, maxLevel: Double = 50.0, ivFloor: Int = 0): PvpTable {
        val key = "${p.id}|${league.name}|$maxLevel|$ivFloor|${g.version}"
        synchronized(cache) { cache[key]?.let { return it } }
        val levels = g.levels.filter { it <= maxLevel }
        val cpms = levels.map { g.cpm(it) }
        val raw = ArrayList<PvpEntry>(4096)
        for (a in ivFloor..15) for (d in ivFloor..15) for (s in ivFloor..15) {
            val iv = Ivs(a, d, s)
            // Höchstes Level unter dem CP-Limit (Binärsuche – CP ist monoton im Level)
            var lo = 0; var hi = levels.size - 1; var bestIdx = -1
            while (lo <= hi) {
                val mid = (lo + hi) / 2
                if (Stats.cp(p, iv, cpms[mid]) <= league.cap) { bestIdx = mid; lo = mid + 1 } else hi = mid - 1
            }
            if (bestIdx < 0) bestIdx = 0 // selbst Level 1 über dem Limit – trotzdem aufnehmen
            val cpm = cpms[bestIdx]
            val sp = Stats.statProduct(p, iv, cpm)
            raw.add(PvpEntry(iv, levels[bestIdx], Stats.cp(p, iv, cpm), sp, Stats.attack(p, a, cpm), Stats.defense(p, d, cpm), Stats.hp(p, s, cpm), 0, 0.0))
        }
        // Sortierung wie PvPoke: Stat-Produkt absteigend, bei Gleichstand Angriff höher zuerst
        raw.sortWith(compareByDescending<PvpEntry> { it.statProduct }.thenByDescending { it.atk })
        val bestSp = raw.first().statProduct
        val ranked = raw.mapIndexed { i, e -> e.copy(rank = i + 1, percentOfBest = e.statProduct / bestSp * 100.0) }
        val t = PvpTable(p, league, maxLevel, ivFloor, ranked)
        synchronized(cache) { if (cache.size > 200) cache.clear(); cache[key] = t }
        return t
    }

    /** Anzahl Sofortattacken bis zur Ladeattacke (PvP). */
    fun fastMovesFor(fast: Move, charged: Move): Int =
        if (fast.pvpEnergy <= 0) 0 else ceil(charged.pvpEnergy.toDouble() / fast.pvpEnergy).toInt()

    /** Gibt Zähler für die 1./2./3. Ladeattacke zurück (Energieüberschuss wird mitgenommen). */
    fun moveCounts(fast: Move, charged: Move): List<Int> {
        if (fast.pvpEnergy <= 0) return emptyList()
        var energy = 0; val out = ArrayList<Int>()
        repeat(3) {
            var n = 0
            while (energy < charged.pvpEnergy) { energy += fast.pvpEnergy; n++ }
            energy -= charged.pvpEnergy
            out.add(n)
        }
        return out
    }

    /** Einfaches PvP-Rating eines Movesets (Schaden pro Energie & Druck). */
    fun movesetScore(g: GameData, p: Pokemon, fast: Move, charged: Move): Double {
        val stab = { m: Move -> if (m.type in p.types) 1.2 else 1.0 }
        val fastDpt = fast.pvpPower * stab(fast) / fast.turns
        val fastEpt = fast.pvpEnergy.toDouble() / fast.turns
        val dpe = charged.pvpPower * stab(charged) / charged.pvpEnergy.coerceAtLeast(1)
        return fastDpt * 1.0 + fastEpt * dpe * 1.3
    }
}
