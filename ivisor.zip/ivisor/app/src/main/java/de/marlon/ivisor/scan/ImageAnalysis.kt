package de.marlon.ivisor.scan

import android.graphics.Bitmap
import de.marlon.ivisor.core.Appraisal
import de.marlon.ivisor.core.ArcMath
import de.marlon.ivisor.core.OcrLine
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class Dot(val x: Float, val y: Float, val diameter: Float)

/** Pixel-Analysen auf dem Screenshot: Level-Bogen-Punkt und Bewertungsbalken. */
object ImageAnalysis {

    /** Findet runde, reinweiße Flecken im oberen Bildbereich (Kandidaten für den Bogenpunkt). */
    fun findWhiteDots(bmp: Bitmap): List<Dot> {
        val w = bmp.width; val h = bmp.height
        val step = max(1, w / 360)
        val y0 = (h * 0.05).toInt(); val y1 = (h * 0.5).toInt()
        val gw = w / step; val gh = (y1 - y0) / step
        if (gw <= 0 || gh <= 0) return emptyList()
        val grid = BooleanArray(gw * gh)
        val row = IntArray(w)
        for (gy in 0 until gh) {
            val y = y0 + gy * step
            bmp.getPixels(row, 0, w, 0, y, w, 1)
            for (gx in 0 until gw) {
                val c = row[gx * step]
                val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
                grid[gy * gw + gx] = r >= 245 && g >= 245 && b >= 245
            }
        }
        val seen = BooleanArray(grid.size)
        val out = ArrayList<Dot>()
        val stack = IntArray(grid.size)
        for (i in grid.indices) {
            if (!grid[i] || seen[i]) continue
            var sp = 0; stack[sp++] = i; seen[i] = true
            var count = 0; var minX = Int.MAX_VALUE; var maxX = 0; var minY = Int.MAX_VALUE; var maxY = 0
            var sx = 0L; var sy = 0L
            while (sp > 0) {
                val p = stack[--sp]; val px = p % gw; val py = p / gw
                count++; sx += px; sy += py
                minX = min(minX, px); maxX = max(maxX, px); minY = min(minY, py); maxY = max(maxY, py)
                if (count > 4000) break
                val n = intArrayOf(p - 1, p + 1, p - gw, p + gw)
                for (q in n) {
                    if (q < 0 || q >= grid.size) continue
                    if ((q % gw - px).let { abs(it) } > 1) continue
                    if (grid[q] && !seen[q]) { seen[q] = true; stack[sp++] = q }
                }
            }
            val bw = maxX - minX + 1; val bh = maxY - minY + 1
            val d = max(bw, bh) * step.toFloat()
            if (d < w * 0.012f || d > w * 0.05f) continue
            val aspect = bw.toFloat() / bh
            if (aspect < 0.7f || aspect > 1.4f) continue
            val fill = count.toFloat() / (bw * bh)
            if (fill < 0.55f || fill > 0.95f) continue
            out.add(Dot((sx.toFloat() / count) * step, y0 + (sy.toFloat() / count) * step, d))
        }
        return out
    }

    /** Punkt auf dem kalibrierten Bogen oder null. */
    fun arcDot(bmp: Bitmap, cyRel: Float, rRel: Float): Dot? =
        findWhiteDots(bmp).filter { ArcMath.onArc(it.x, it.y, bmp.width, bmp.height, cyRel, rRel) }
            .minByOrNull { d ->
                val dx = d.x - bmp.width / 2f; val dy = d.y - cyRel * bmp.height
                abs(kotlin.math.sqrt(dx * dx + dy * dy) - rRel * bmp.width)
            }

    /**
     * Liest die drei Bewertungsbalken (Angriff / Verteidigung / KP). Liefert Bereiche ±1,
     * bei vollem (rotem) Balken exakt 15. Null, wenn nicht gefunden.
     */
    fun readAppraisal(bmp: Bitmap, lines: List<OcrLine>): Appraisal? {
        val h = bmp.height
        fun label(vararg keys: String) = lines.filter { it.cy > h * 0.45 }.firstOrNull { l ->
            val u = l.text.trim().uppercase(); keys.any { u == it || u.startsWith(it) }
        }
        val atk = label("ANGRIFF", "ATTACK", "ATTAQUE") ?: return null
        val def = label("VERTEIDIGUNG", "DEFENSE", "DÉFENSE") ?: return null
        val sta = label("KP", "HP", "PV", "STAMINA", "AUSDAUER") ?: return null
        val a = readBar(bmp, atk) ?: return null
        val d = readBar(bmp, def) ?: return null
        val s = readBar(bmp, sta) ?: return null
        return Appraisal(a, d, s)
    }

    private fun readBar(bmp: Bitmap, label: OcrLine): IntRange? {
        val w = bmp.width
        val gapTol = (w * 0.03f).toInt()
        // Balken liegt knapp unter dem Label – mehrere Zeilen probieren
        for (k in listOf(0.9f, 1.2f, 0.6f, 1.5f)) {
            val y = (label.bottom + label.height * k).toInt()
            if (y !in 0 until bmp.height) continue
            val row = IntArray(w); bmp.getPixels(row, 0, w, 0, y, w, 1)
            var start = -1; var end = -1; var filled = 0; var red = 0; var gap = 0
            val x0 = max(0, label.left - (w * 0.02f).toInt())
            for (x in x0 until (w * 0.97f).toInt()) {
                val c = row[x]
                val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
                val isFill = r > 170 && r - b > 60 && r >= g
                val isEmpty = !isFill && abs(r - g) < 14 && abs(g - b) < 14 && r in 185..238
                if (isFill || isEmpty) {
                    if (start < 0) start = x
                    end = x; gap = 0
                    if (isFill) { filled++; if (g < 150) red++ }
                } else if (start >= 0) {
                    gap++
                    if (gap > gapTol) break
                }
            }
            if (start < 0) continue
            val len = end - start + 1
            if (len < w * 0.2f) continue
            val frac = filled.toFloat() / len
            if (frac > 0.97f && red > filled * 0.5f) return 15..15
            val iv = (frac * 15).roundToInt().coerceIn(0, 15)
            return (iv - 1).coerceAtLeast(0)..(iv + 1).coerceAtMost(15)
        }
        return null
    }
}
